# Keep native JNI methods
-keepclasseswithmembernames class * {
    native <methods>;
}

# Keep Room entities and DAOs
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-keepclassmembers class * {
    @androidx.room.Dao *;
}

# Keep Gson serialization models
-keepclassmembers class com.nova.voiceai.core.llm.** { *; }
