#include <jni.h>
#include <android/log.h>
#include <cmath>
#include <vector>
#include <algorithm>
#include <cstring>

#define TAG "NovaAudioDSP"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, TAG, __VA_ARGS__)

extern "C" {

JNIEXPORT jfloat JNICALL
Java_com_nova_voiceai_core_audio_AudioRecorderManager_nativeCalculateRms(
    JNIEnv* env,
    jobject /* this */,
    jshortArray audioData,
    jint length
) {
    if (!audioData || length <= 0) return 0.0f;

    jshort* samples = env->GetShortArrayElements(audioData, nullptr);
    if (!samples) return 0.0f;

    double sumSq = 0.0;
    for (int i = 0; i < length; ++i) {
        double normalized = static_cast<double>(samples[i]) / 32768.0;
        sumSq += normalized * normalized;
    }

    env->ReleaseShortArrayElements(audioData, samples, JNI_ABORT);

    double rms = std::sqrt(sumSq / static_cast<double>(length));
    return static_cast<jfloat>(rms);
}

/**
 * Analyzes audio frame specifically for Human Vocal Pitch (Fundamental Frequency F0)
 * and Voicing periodicity.
 *
 * Human vocal cords generate fundamental frequencies strictly in [85 Hz, 280 Hz].
 * At 16 kHz sample rate:
 * - Minimum lag (280 Hz) = 16000 / 280 = 57 samples
 * - Maximum lag (85 Hz)  = 16000 / 85  = 188 samples
 *
 * Returns:
 * outPitch[0] = Detected F0 frequency in Hz (0 if unvoiced/non-human)
 * outPitch[1] = Voicing periodicity confidence [0.0 - 1.0] (Autocorrelation peak)
 * outPitch[2] = Zero-crossing rate [0.0 - 1.0]
 */
JNIEXPORT jboolean JNICALL
Java_com_nova_voiceai_core_bargein_BargeInController_nativeAnalyzeHumanVoicePitch(
    JNIEnv* env,
    jobject /* this */,
    jshortArray audioData,
    jint length,
    jint sampleRate,
    jfloatArray outResult
) {
    if (!audioData || length < 256) return JNI_FALSE;

    jshort* samples = env->GetShortArrayElements(audioData, nullptr);
    if (!samples) return JNI_FALSE;

    // 1. Calculate Zero-Crossing Rate (ZCR)
    int zeroCrossings = 0;
    for (int i = 1; i < length; ++i) {
        if ((samples[i] >= 0 && samples[i - 1] < 0) || (samples[i] < 0 && samples[i - 1] >= 0)) {
            zeroCrossings++;
        }
    }
    float zcr = static_cast<float>(zeroCrossings) / static_cast<float>(length);

    // 2. Multi-Lag Autocorrelation: Check lags from 16 (1000 Hz) to 200 (80 Hz)
    // Energy at lag 0
    double energy0 = 0.0;
    for (int i = 0; i < length; ++i) {
        double val = static_cast<double>(samples[i]) / 32768.0;
        energy0 += val * val;
    }

    float bestPitch = 0.0f;
    float maxCorr = 0.0f;
    int firstPeakLag = 0;

    if (energy0 > 0.0001) {
        std::vector<float> corrs(202, 0.0f);
        int maxLag = std::min(200, length - 1);

        for (int lag = 16; lag <= maxLag; ++lag) {
            double crossSum = 0.0;
            double lagEnergy = 0.0;
            int count = length - lag;

            for (int i = 0; i < count; ++i) {
                double s1 = static_cast<double>(samples[i]) / 32768.0;
                double s2 = static_cast<double>(samples[i + lag]) / 32768.0;
                crossSum += s1 * s2;
                lagEnergy += s2 * s2;
            }

            double norm = std::sqrt(energy0 * lagEnergy);
            if (norm > 0.0) {
                corrs[lag] = static_cast<float>(crossSum / norm);
            }
        }

        // Find the FIRST significant local peak to prevent harmonic sub-multiples
        for (int lag = 18; lag < maxLag; ++lag) {
            if (corrs[lag] > corrs[lag - 1] && corrs[lag] > corrs[lag + 1] && corrs[lag] > 0.46f) {
                firstPeakLag = lag;
                maxCorr = corrs[lag];
                break;
            }
        }
    }

    // Human fundamental pitch must have first peak in lag [57, 188] (85 Hz - 280 Hz)
    if (firstPeakLag >= 57 && firstPeakLag <= 188 && maxCorr >= 0.46f && zcr < 0.32f) {
        bestPitch = static_cast<float>(sampleRate) / static_cast<float>(firstPeakLag);
    }

    env->ReleaseShortArrayElements(audioData, samples, JNI_ABORT);

    // Human vocal tone criteria:
    // Pitch between 85 Hz and 280 Hz, strong autocorrelation peak > 0.48, ZCR < 0.28
    bool isHuman = (bestPitch >= 85.0f && bestPitch <= 280.0f && maxCorr >= 0.48f);

    if (outResult && env->GetArrayLength(outResult) >= 3) {
        float res[3] = { bestPitch, maxCorr, zcr };
        env->SetFloatArrayRegion(outResult, 0, 3, res);
    }

    return isHuman ? JNI_TRUE : JNI_FALSE;
}

/**
 * Checks Normalized Cross-Correlation between Microphone input and AI Speaker Playback Reference.
 * Returns similarity [0.0 - 1.0].
 * If similarity > 0.35, the sound is confirmed to be the AI speaking through the phone speaker.
 */
JNIEXPORT jfloat JNICALL
Java_com_nova_voiceai_core_bargein_BargeInController_nativeCheckAiEchoCorrelation(
    JNIEnv* env,
    jobject /* this */,
    jshortArray micBuffer,
    jshortArray refPlaybackBuffer,
    jint length
) {
    if (!micBuffer || !refPlaybackBuffer || length < 128) return 0.0f;

    jshort* mic = env->GetShortArrayElements(micBuffer, nullptr);
    jshort* ref = env->GetShortArrayElements(refPlaybackBuffer, nullptr);
    if (!mic || !ref) {
        if (mic) env->ReleaseShortArrayElements(micBuffer, mic, JNI_ABORT);
        if (ref) env->ReleaseShortArrayElements(refPlaybackBuffer, ref, JNI_ABORT);
        return 0.0f;
    }

    double micEnergy = 0.0;
    double refEnergy = 0.0;
    for (int i = 0; i < length; ++i) {
        double m = static_cast<double>(mic[i]) / 32768.0;
        double r = static_cast<double>(ref[i]) / 32768.0;
        micEnergy += m * m;
        refEnergy += r * r;
    }

    if (micEnergy < 0.0001 || refEnergy < 0.0001) {
        env->ReleaseShortArrayElements(micBuffer, mic, JNI_ABORT);
        env->ReleaseShortArrayElements(refPlaybackBuffer, ref, JNI_ABORT);
        return 0.0f;
    }

    // Check cross-correlation across small acoustic flight delay (0 - 40ms = 0 - 640 samples)
    float maxCorr = 0.0f;
    int maxDelay = std::min(length / 2, 640);

    for (int delay = 0; delay < maxDelay; delay += 16) {
        double cross = 0.0;
        int count = length - delay;
        for (int i = 0; i < count; ++i) {
            double m = static_cast<double>(mic[i + delay]) / 32768.0;
            double r = static_cast<double>(ref[i]) / 32768.0;
            cross += m * r;
        }
        double norm = std::sqrt(micEnergy * refEnergy);
        float corr = static_cast<float>(cross / norm);
        if (corr > maxCorr) {
            maxCorr = corr;
        }
    }

    env->ReleaseShortArrayElements(micBuffer, mic, JNI_ABORT);
    env->ReleaseShortArrayElements(refPlaybackBuffer, ref, JNI_ABORT);

    return maxCorr;
}

JNIEXPORT void JNICALL
Java_com_nova_voiceai_core_audio_AcousticEchoController_nativeSubtractReference(
    JNIEnv* env,
    jobject /* this */,
    jshortArray micBuffer,
    jshortArray refBuffer,
    jint length,
    jfloat suppressionFactor
) {
    if (!micBuffer || !refBuffer || length <= 0) return;

    jshort* mic = env->GetShortArrayElements(micBuffer, nullptr);
    jshort* ref = env->GetShortArrayElements(refBuffer, nullptr);

    if (mic && ref) {
        for (int i = 0; i < length; ++i) {
            float m = static_cast<float>(mic[i]);
            float r = static_cast<float>(ref[i]) * suppressionFactor;
            float out = m - r;

            if (out > 32767.0f) out = 32767.0f;
            else if (out < -32768.0f) out = -32768.0f;

            mic[i] = static_cast<int16_t>(out);
        }
    }

    if (mic) env->ReleaseShortArrayElements(micBuffer, mic, 0);
    if (ref) env->ReleaseShortArrayElements(refBuffer, ref, JNI_ABORT);
}

} // extern "C"
