#include <jni.h>
#include <android/log.h>
#include <cmath>
#include <vector>
#include <numeric>

#define TAG "NovaNativeVAD"

class EnergyVadEngine {
private:
    float noiseFloor = 0.008f;
    float speechThreshold = 0.022f;
    float alphaNoise = 0.96f;
    float userSensitivity = 1.0f;

public:
    EnergyVadEngine() {}

    void setSensitivity(float factor) {
        userSensitivity = std::max(0.3f, std::min(factor, 3.0f));
        speechThreshold = std::max(0.012f, 0.022f / userSensitivity);
    }

    bool processFrame(const int16_t* samples, int numSamples, float& frameEnergy) {
        double sumSq = 0.0;
        for (int i = 0; i < numSamples; ++i) {
            double n = static_cast<double>(samples[i]) / 32768.0;
            sumSq += n * n;
        }
        frameEnergy = static_cast<float>(std::sqrt(sumSq / numSamples));

        // Dynamic threshold tracking noise floor
        float currentDynamicThresh = std::max(speechThreshold, noiseFloor * 2.4f);

        bool isSpeech = (frameEnergy >= currentDynamicThresh);

        if (!isSpeech) {
            // Adapt noise floor during silence
            noiseFloor = alphaNoise * noiseFloor + (1.0f - alphaNoise) * frameEnergy;
        }

        return isSpeech;
    }
};

static EnergyVadEngine g_vadEngine;

extern "C" {

JNIEXPORT void JNICALL
Java_com_nova_voiceai_core_vad_VadDetector_nativeSetSensitivity(
    JNIEnv* env,
    jobject /* this */,
    jfloat sensitivity
) {
    g_vadEngine.setSensitivity(sensitivity);
}

JNIEXPORT jboolean JNICALL
Java_com_nova_voiceai_core_vad_VadDetector_nativeProcessFrame(
    JNIEnv* env,
    jobject /* this */,
    jshortArray audioData,
    jint length,
    jfloatArray outEnergy
) {
    if (!audioData || length <= 0) return JNI_FALSE;

    jshort* samples = env->GetShortArrayElements(audioData, nullptr);
    if (!samples) return JNI_FALSE;

    float energy = 0.0f;
    bool isSpeech = g_vadEngine.processFrame(samples, length, energy);

    env->ReleaseShortArrayElements(audioData, samples, JNI_ABORT);

    if (outEnergy && env->GetArrayLength(outEnergy) > 0) {
        env->SetFloatArrayRegion(outEnergy, 0, 1, &energy);
    }

    return isSpeech ? JNI_TRUE : JNI_FALSE;
}

} // extern "C"
