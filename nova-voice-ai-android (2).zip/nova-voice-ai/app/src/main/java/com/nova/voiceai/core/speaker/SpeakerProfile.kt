package com.nova.voiceai.core.speaker

data class SpeakerProfile(
    val embedding: FloatArray = FloatArray(64),
    val sampleCount: Int = 0,
    val isEnrolled: Boolean = false,
    val lastConfidence: Float = 0f
)
