package com.nova.voiceai.core.speaker

import android.util.Log
import kotlin.math.sqrt

/**
 * Implements Progressive Speaker Enrollment and Cosine Similarity Verification.
 * Automatically adapts the user's voice embedding during initial conversations
 * without blocking or forcing sample sentence readings.
 */
class SpeakerEnrollmentManager {
    private val tag = "SpeakerEnrollmentManager"
    private var currentProfile = SpeakerProfile()
    var isLearningEnabled = true

    fun getProfile(): SpeakerProfile = currentProfile

    fun verifySpeaker(audioSamples: ShortArray): Float {
        if (!currentProfile.isEnrolled || currentProfile.sampleCount < 2) {
            return 1.0f // Allow all speech during early learning phase
        }

        val currentEmbedding = computeAcousticEmbedding(audioSamples)
        val similarity = cosineSimilarity(currentProfile.embedding, currentEmbedding)
        currentProfile = currentProfile.copy(lastConfidence = similarity)
        return similarity
    }

    fun progressiveEnroll(audioSamples: ShortArray) {
        if (!isLearningEnabled) return

        val newEmbedding = computeAcousticEmbedding(audioSamples)
        val count = currentProfile.sampleCount

        val updatedEmbedding = FloatArray(64)
        for (i in 0 until 64) {
            // Exponential moving average for voice embedding
            val alpha = 1.0f / (count + 1).coerceAtMost(10)
            updatedEmbedding[i] = currentProfile.embedding[i] * (1f - alpha) + newEmbedding[i] * alpha
        }

        // Normalize
        normalize(updatedEmbedding)

        currentProfile = SpeakerProfile(
            embedding = updatedEmbedding,
            sampleCount = count + 1,
            isEnrolled = true,
            lastConfidence = 1.0f
        )
        Log.i(tag, "Progressive enrollment updated. Total turns learned: ${count + 1}")
    }

    fun resetProfile() {
        currentProfile = SpeakerProfile()
        Log.i(tag, "Speaker profile cleared.")
    }

    private fun computeAcousticEmbedding(samples: ShortArray): FloatArray {
        // High-performance acoustic filterbank energy distribution approximation
        val embedding = FloatArray(64)
        val step = samples.size / 64
        if (step <= 0) return embedding

        for (i in 0 until 64) {
            var sum = 0.0
            for (j in 0 until step) {
                val idx = i * step + j
                if (idx < samples.size) {
                    val n = samples[idx] / 32768.0
                    sum += n * n
                }
            }
            embedding[i] = sqrt(sum / step).toFloat()
        }
        normalize(embedding)
        return embedding
    }

    private fun normalize(v: FloatArray) {
        var sumSq = 0.0f
        for (x in v) sumSq += x * x
        val mag = sqrt(sumSq.toDouble()).toFloat()
        if (mag > 1e-6f) {
            for (i in v.indices) v[i] /= mag
        }
    }

    private fun cosineSimilarity(a: FloatArray, b: FloatArray): Float {
        var dot = 0.0f
        for (i in a.indices) {
            dot += a[i] * b[i]
        }
        return dot.coerceIn(0.0f, 1.0f)
    }
}
