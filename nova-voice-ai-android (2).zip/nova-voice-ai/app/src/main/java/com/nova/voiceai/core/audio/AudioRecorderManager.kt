package com.nova.voiceai.core.audio

import android.annotation.SuppressLint
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicBoolean

class AudioRecorderManager(
    private val echoController: AcousticEchoController = AcousticEchoController()
) {
    private val tag = "AudioRecorderManager"
    private var audioRecord: AudioRecord? = null
    private val isRecording = AtomicBoolean(false)
    private var recordingJob: Job? = null

    private val _micLevelFlow = MutableStateFlow(0f)
    val micLevelFlow: StateFlow<Float> = _micLevelFlow.asStateFlow()

    val preRollBuffer = CircularAudioBuffer(AudioConstants.SAMPLE_RATE * 2) // 2 sec pre-roll

    companion object {
        init {
            try {
                System.loadLibrary("nova_native")
            } catch (e: UnsatisfiedLinkError) {
                Log.e("AudioRecorderManager", "Failed to load nova_native library: ${e.message}")
            }
        }
    }

    private external fun nativeCalculateRms(audioData: ShortArray, length: Int): Float

    @SuppressLint("MissingPermission")
    fun startRecording(
        scope: CoroutineScope,
        onFrameReceived: (ShortArray, Int, Float) -> Unit
    ): Boolean {
        if (isRecording.get()) return true

        val minBufferSize = AudioRecord.getMinBufferSize(
            AudioConstants.SAMPLE_RATE,
            AudioConstants.CHANNEL_CONFIG,
            AudioConstants.AUDIO_FORMAT
        )
        val bufferSize = maxOf(minBufferSize, AudioConstants.FRAME_SIZE_BYTES * 4)

        try {
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                AudioConstants.SAMPLE_RATE,
                AudioConstants.CHANNEL_CONFIG,
                AudioConstants.AUDIO_FORMAT,
                bufferSize
            )

            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                Log.e(tag, "AudioRecord failed to initialize")
                return false
            }

            val sessionId = audioRecord?.audioSessionId ?: 0
            echoController.attachHardwareEffects(sessionId)

            audioRecord?.startRecording()
            isRecording.set(true)
            preRollBuffer.clear()

            recordingJob = scope.launch(Dispatchers.IO) {
                val frameBuffer = ShortArray(AudioConstants.SAMPLES_PER_FRAME)
                while (isRecording.get() && isActive) {
                    val readSamples = audioRecord?.read(frameBuffer, 0, frameBuffer.size) ?: 0
                    if (readSamples > 0) {
                        preRollBuffer.write(frameBuffer, 0, readSamples)
                        val rms = nativeCalculateRms(frameBuffer, readSamples)
                        _micLevelFlow.value = rms
                        onFrameReceived(frameBuffer, readSamples, rms)
                    }
                }
            }
            Log.i(tag, "AudioRecord started successfully at ${AudioConstants.SAMPLE_RATE}Hz")
            return true
        } catch (e: Exception) {
            Log.e(tag, "Error starting AudioRecord: ${e.message}", e)
            return false
        }
    }

    fun stopRecording() {
        if (!isRecording.getAndSet(false)) return
        recordingJob?.cancel()
        recordingJob = null
        try {
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
            echoController.release()
            Log.i(tag, "AudioRecord stopped and released")
        } catch (e: Exception) {
            Log.e(tag, "Error stopping AudioRecord: ${e.message}")
        }
    }
}
