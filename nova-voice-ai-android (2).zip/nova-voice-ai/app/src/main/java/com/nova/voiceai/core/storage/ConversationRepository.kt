package com.nova.voiceai.core.storage

import com.nova.voiceai.core.llm.LlmMessage
import com.nova.voiceai.core.storage.data.ChatDao
import com.nova.voiceai.core.storage.data.ChatMessageEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class ConversationRepository(private val chatDao: ChatDao) {
    val messagesFlow: Flow<List<ChatMessageEntity>> = chatDao.getAllMessages()

    suspend fun addMessage(role: String, content: String) {
        chatDao.insertMessage(ChatMessageEntity(role = role, content = content))
    }

    suspend fun clearAll() {
        chatDao.clearHistory()
    }

    fun getLlmHistory(): Flow<List<LlmMessage>> {
        return messagesFlow.map { list ->
            list.takeLast(10).map { LlmMessage(role = it.role, content = it.content) }
        }
    }
}
