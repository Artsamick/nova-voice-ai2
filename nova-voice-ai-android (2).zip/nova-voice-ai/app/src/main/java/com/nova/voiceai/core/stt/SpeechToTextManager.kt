package com.nova.voiceai.core.stt

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.util.concurrent.atomic.AtomicBoolean

class SpeechToTextManager(private val context: Context) {
    private val tag = "SpeechToTextManager"
    private var speechRecognizer: SpeechRecognizer? = null
    val isListening = AtomicBoolean(false)

    private val _sttFlow = MutableSharedFlow<SttResult>(extraBufferCapacity = 32)
    val sttFlow: SharedFlow<SttResult> = _sttFlow.asSharedFlow()

    // Holds the latest partial transcription text so it can never be lost on endpoint
    var latestPartialText: String = ""
        private set

    fun initRecognizer() {
        try {
            if (SpeechRecognizer.isRecognitionAvailable(context)) {
                speechRecognizer?.destroy()
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(createListener())
                }
                Log.i(tag, "SpeechRecognizer created successfully for Thai language.")
            }
        } catch (e: Exception) {
            Log.e(tag, "Error initializing SpeechRecognizer: ${e.message}")
        }
    }

    fun startListening(languageCode: String = "th-TH") {
        if (isListening.get()) return
        latestPartialText = ""

        if (speechRecognizer == null) {
            initRecognizer()
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageCode)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageCode)
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, languageCode)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 700L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 500L)
        }

        try {
            speechRecognizer?.startListening(intent)
            isListening.set(true)
            Log.i(tag, "STT listening active for language: $languageCode")
        } catch (e: Exception) {
            Log.e(tag, "Error invoking startListening: ${e.message}")
            isListening.set(false)
            _sttFlow.tryEmit(SttResult.Error("Failed to start STT: ${e.message}"))
        }
    }

    fun stopListening() {
        if (!isListening.getAndSet(false)) return
        try {
            speechRecognizer?.stopListening()
            Log.i(tag, "STT stopListening requested")
        } catch (e: Exception) {
            Log.w(tag, "Error in stopListening: ${e.message}")
        }
    }

    fun release() {
        isListening.set(false)
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (e: Exception) {
            Log.w(tag, "Error destroying speechRecognizer: ${e.message}")
        }
    }

    private fun createListener(): RecognitionListener {
        return object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                Log.d(tag, "STT onReadyForSpeech")
            }

            override fun onBeginningOfSpeech() {
                Log.d(tag, "STT onBeginningOfSpeech")
            }

            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                Log.d(tag, "STT onEndOfSpeech detected")
                isListening.set(false)
            }

            override fun onError(error: Int) {
                isListening.set(false)
                val errorMsg = when (error) {
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
                    SpeechRecognizer.ERROR_NETWORK -> "Network error"
                    SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                    SpeechRecognizer.ERROR_SERVER -> "Server error"
                    SpeechRecognizer.ERROR_CLIENT -> "Client error"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech input"
                    SpeechRecognizer.ERROR_NO_MATCH -> "No match recognized"
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Insufficient permissions"
                    else -> "Error ($error)"
                }
                Log.w(tag, "STT Error: $errorMsg (latestPartial: '$latestPartialText')")

                // If we already accumulated text before the error, promote it to Final result!
                if (latestPartialText.isNotBlank()) {
                    Log.i(tag, "Promoting partial text on error to Final: '$latestPartialText'")
                    _sttFlow.tryEmit(SttResult.Final(latestPartialText))
                } else {
                    _sttFlow.tryEmit(SttResult.Error(errorMsg))
                }
            }

            override fun onResults(results: Bundle?) {
                isListening.set(false)
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val finalText = matches?.firstOrNull()?.trim() ?: latestPartialText.trim()
                Log.i(tag, "STT onResults: '$finalText'")
                _sttFlow.tryEmit(SttResult.Final(finalText))
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull()?.trim() ?: ""
                if (text.isNotBlank()) {
                    latestPartialText = text
                    Log.d(tag, "STT onPartialResults: '$text'")
                    _sttFlow.tryEmit(SttResult.Partial(text))
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }
}
