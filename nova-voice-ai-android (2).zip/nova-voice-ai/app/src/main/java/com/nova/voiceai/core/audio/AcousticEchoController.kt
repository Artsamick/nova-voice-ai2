package com.nova.voiceai.core.audio

import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.util.Log

class AcousticEchoController {
    private val tag = "AcousticEchoController"
    private var aec: AcousticEchoCanceler? = null
    private var ns: NoiseSuppressor? = null

    companion object {
        init {
            try {
                System.loadLibrary("nova_native")
            } catch (e: UnsatisfiedLinkError) {
                Log.e("AcousticEchoController", "Failed to load nova_native library: ${e.message}")
            }
        }
    }

    external fun nativeSubtractReference(
        micBuffer: ShortArray,
        refBuffer: ShortArray,
        length: Int,
        suppressionFactor: Float
    )

    fun attachHardwareEffects(audioSessionId: Int) {
        if (AcousticEchoCanceler.isAvailable()) {
            try {
                aec = AcousticEchoCanceler.create(audioSessionId)?.apply {
                    enabled = true
                    Log.i(tag, "Hardware AcousticEchoCanceler enabled on session $audioSessionId")
                }
            } catch (e: Exception) {
                Log.w(tag, "Could not enable hardware AEC: ${e.message}")
            }
        } else {
            Log.i(tag, "Hardware AEC not available on this device; using native DSP echo subtraction.")
        }

        if (NoiseSuppressor.isAvailable()) {
            try {
                ns = NoiseSuppressor.create(audioSessionId)?.apply {
                    enabled = true
                    Log.i(tag, "Hardware NoiseSuppressor enabled on session $audioSessionId")
                }
            } catch (e: Exception) {
                Log.w(tag, "Could not enable hardware NS: ${e.message}")
            }
        }
    }

    fun release() {
        aec?.release()
        aec = null
        ns?.release()
        ns = null
    }
}
