package com.nova.voiceai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.nova.voiceai.core.audio.AudioRecorderManager
import com.nova.voiceai.core.audio.AudioTrackPlayer
import com.nova.voiceai.core.bargein.BargeInController
import com.nova.voiceai.core.llm.LocalLlamaEngine
import com.nova.voiceai.core.llm.OpenRouterClient
import com.nova.voiceai.core.speaker.SpeakerEnrollmentManager
import com.nova.voiceai.core.storage.ConversationRepository
import com.nova.voiceai.core.stt.SpeechToTextManager
import com.nova.voiceai.core.tts.TextToSpeechManager
import com.nova.voiceai.core.vad.VadDetector
import com.nova.voiceai.engine.ConversationCoordinator
import com.nova.voiceai.engine.ConversationStateMachine
import com.nova.voiceai.service.VoiceInteractionService
import com.nova.voiceai.ui.screens.MainConversationScreen
import com.nova.voiceai.ui.screens.SettingsModalSheet
import com.nova.voiceai.ui.theme.NovaVoiceAITheme

class MainActivity : ComponentActivity() {

    private lateinit var coordinator: ConversationCoordinator

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val recordAudioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
        if (recordAudioGranted) {
            startForegroundServiceIntent()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val app = application as NovaApplication
        val prefs = app.securePreferences
        val db = app.database
        val repo = ConversationRepository(db.chatDao())

        val stateMachine = ConversationStateMachine()
        val audioRecorder = AudioRecorderManager()
        val audioPlayer = AudioTrackPlayer()
        val vadDetector = VadDetector()
        val bargeIn = BargeInController()
        val speaker = SpeakerEnrollmentManager()
        val stt = SpeechToTextManager(this)
        val tts = TextToSpeechManager(this)

        val localLlama = LocalLlamaEngine(this)
        val openRouter = OpenRouterClient(apiKey = prefs.openRouterApiKey, currentModel = prefs.selectedModel)

        val activeLlm = if (prefs.selectedProvider == "OPENROUTER") openRouter else localLlama

        coordinator = ConversationCoordinator(
            context = this,
            stateMachine = stateMachine,
            audioRecorder = audioRecorder,
            audioPlayer = audioPlayer,
            vadDetector = vadDetector,
            bargeInController = bargeIn,
            speakerEnrollment = speaker,
            sttManager = stt,
            ttsManager = tts,
            repository = repo,
            llmEngine = activeLlm
        )

        checkPermissions()

        setContent {
            NovaVoiceAITheme {
                var showSettingsSheet by remember { mutableStateOf(false) }
                var settingsInitialTab by remember { mutableStateOf(0) }

                MainConversationScreen(
                    coordinator = coordinator,
                    onOpenSettings = { tabIndex ->
                        settingsInitialTab = tabIndex
                        showSettingsSheet = true
                    }
                )

                if (showSettingsSheet) {
                    ModalBottomSheet(
                        onDismissRequest = { showSettingsSheet = false },
                        containerColor = com.nova.voiceai.ui.theme.ModalBackground
                    ) {
                        SettingsModalSheet(
                            prefs = prefs,
                            initialTab = settingsInitialTab,
                            onTestVoice = {
                                tts.speak("สวัสดีครับ ผมคือระบบเสียง NOVA พร้อมสนทนาแล้วครับ", System.currentTimeMillis())
                            },
                            onDismiss = {
                                showSettingsSheet = false
                                // Update active engine if provider changed
                                coordinator.llmEngine = if (prefs.selectedProvider == "OPENROUTER") {
                                    openRouter.setKey(prefs.openRouterApiKey)
                                    openRouter.currentModel = prefs.selectedModel
                                    openRouter
                                } else {
                                    localLlama
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    private fun checkPermissions() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        val allGranted = permissions.all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

        if (!allGranted) {
            requestPermissionLauncher.launch(permissions.toTypedArray())
        } else {
            startForegroundServiceIntent()
        }
    }

    private fun startForegroundServiceIntent() {
        val intent = Intent(this, VoiceInteractionService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        coordinator.stopSession()
        coordinator.audioRecorder.stopRecording()
        coordinator.ttsManager.release()
        coordinator.sttManager.release()
    }
}
