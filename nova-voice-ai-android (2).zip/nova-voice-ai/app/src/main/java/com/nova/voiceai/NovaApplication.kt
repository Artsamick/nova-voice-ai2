package com.nova.voiceai

import android.app.Application
import com.nova.voiceai.core.storage.SecurePreferencesManager
import com.nova.voiceai.core.storage.data.NovaDatabase

class NovaApplication : Application() {
    lateinit var securePreferences: SecurePreferencesManager
    lateinit var database: NovaDatabase

    override fun onCreate() {
        super.onCreate()
        securePreferences = SecurePreferencesManager(this)
        database = NovaDatabase.getInstance(this)
    }
}
