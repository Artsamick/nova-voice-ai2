package com.nova.voiceai.core.storage

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class SecurePreferencesManager(context: Context) {
    private val sharedPreferences: SharedPreferences

    init {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        sharedPreferences = EncryptedSharedPreferences.create(
            context,
            "nova_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    var openRouterApiKey: String
        get() = sharedPreferences.getString("openrouter_api_key", "") ?: ""
        set(value) = sharedPreferences.edit().putString("openrouter_api_key", value).apply()

    var selectedProvider: String // "LOCAL" or "OPENROUTER"
        get() = sharedPreferences.getString("selected_provider", "LOCAL") ?: "LOCAL"
        set(value) = sharedPreferences.edit().putString("selected_provider", value).apply()

    var selectedModel: String
        get() = sharedPreferences.getString("selected_model", "openrouter/free") ?: "openrouter/free"
        set(value) = sharedPreferences.edit().putString("selected_model", value).apply()

    var orbPreset: String // "BLUE_GOLD", "ICE_BLUE", "AMBER", etc.
        get() = sharedPreferences.getString("orb_preset", "BLUE_GOLD") ?: "BLUE_GOLD"
        set(value) = sharedPreferences.edit().putString("orb_preset", value).apply()

    var audioSensitivity: Float
        get() = sharedPreferences.getFloat("audio_sensitivity", 1.2f)
        set(value) = sharedPreferences.edit().putFloat("audio_sensitivity", value).apply()

    var speechRate: Float
        get() = sharedPreferences.getFloat("speech_rate", 1.05f)
        set(value) = sharedPreferences.edit().putFloat("speech_rate", value).apply()

    var reduceMotion: Boolean
        get() = sharedPreferences.getBoolean("reduce_motion", false)
        set(value) = sharedPreferences.edit().putBoolean("reduce_motion", value).apply()

    fun clearAll() {
        sharedPreferences.edit().clear().apply()
    }
}
