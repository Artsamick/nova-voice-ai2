package com.nova.voiceai.core.tts

enum class TtsState {
    IDLE,
    SYNTHESIZING,
    SPEAKING,
    INTERRUPTED,
    COMPLETED,
    ERROR
}
