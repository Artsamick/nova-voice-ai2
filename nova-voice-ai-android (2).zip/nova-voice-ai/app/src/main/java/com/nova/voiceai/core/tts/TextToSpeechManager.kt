package com.nova.voiceai.core.tts

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID
import java.util.concurrent.atomic.AtomicLong

class TextToSpeechManager(private val context: Context) : TextToSpeech.OnInitListener {
    private val tag = "TextToSpeechManager"
    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val currentGenerationId = AtomicLong(0L)

    private val _ttsStateFlow = MutableStateFlow(TtsState.IDLE)
    val ttsStateFlow: StateFlow<TtsState> = _ttsStateFlow.asStateFlow()

    var speechRate: Float = 1.05f
        set(value) {
            field = value
            tts?.setSpeechRate(value)
        }

    var pitch: Float = 1.0f
        set(value) {
            field = value
            tts?.setPitch(value)
        }

    init {
        tts = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val thaiLocale = Locale("th", "TH")
            val result = tts?.setLanguage(thaiLocale)

            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.w(tag, "Thai TTS not fully supported, falling back to default locale.")
                tts?.setLanguage(Locale.getDefault())
            } else {
                Log.i(tag, "Thai TTS language loaded successfully.")
            }

            tts?.setSpeechRate(speechRate)
            tts?.setPitch(pitch)
            setupListener()
            isInitialized = true
        } else {
            Log.e(tag, "Failed to initialize Android TextToSpeech.")
            _ttsStateFlow.value = TtsState.ERROR
        }
    }

    private fun setupListener() {
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                Log.d(tag, "TTS Started: $utteranceId")
                _ttsStateFlow.value = TtsState.SPEAKING
            }

            override fun onDone(utteranceId: String?) {
                Log.d(tag, "TTS Done: $utteranceId")
                _ttsStateFlow.value = TtsState.COMPLETED
            }

            override fun onError(utteranceId: String?) {
                Log.e(tag, "TTS Error: $utteranceId")
                _ttsStateFlow.value = TtsState.ERROR
            }
        })
    }

    /**
     * Speaks the given text chunk. Sanitizes markdown tags, emojis, and code blocks before speaking.
     * Generates a unique generationId so stale tokens or interrupted utterances can be invalidated immediately.
     */
    fun speak(text: String, generationId: Long): Boolean {
        if (!isInitialized || tts == null) {
            Log.w(tag, "TTS not ready to speak.")
            return false
        }

        // Validate generation ID
        if (generationId < currentGenerationId.get()) {
            Log.d(tag, "Ignoring stale TTS generationId: $generationId (current: ${currentGenerationId.get()})")
            return false
        }
        currentGenerationId.set(generationId)

        val cleanText = sanitizeTextForSpeech(text)
        if (cleanText.isBlank()) return true

        val utteranceId = "nova_utt_${generationId}_${UUID.randomUUID()}"
        _ttsStateFlow.value = TtsState.SYNTHESIZING

        val result = tts?.speak(cleanText, TextToSpeech.QUEUE_ADD, null, utteranceId)
        return result == TextToSpeech.SUCCESS
    }

    /**
     * Instant Barge-in stop: flushes any queued utterances, advances generation ID, and silences speaker immediately.
     */
    fun stopImmediately() {
        currentGenerationId.incrementAndGet()
        try {
            tts?.stop()
            _ttsStateFlow.value = TtsState.INTERRUPTED
            Log.i(tag, "TTS Stopped immediately due to Barge-in.")
        } catch (e: Exception) {
            Log.e(tag, "Error stopping TTS: ${e.message}")
        }
    }

    fun release() {
        try {
            tts?.stop()
            tts?.shutdown()
            tts = null
        } catch (e: Exception) {
            Log.w(tag, "Error shutting down TTS: ${e.message}")
        }
    }

    companion object {
        fun sanitizeTextForSpeech(input: String): String {
            return input
                .replace(Regex("```[\s\S]*?```"), "") // Remove code blocks
                .replace(Regex("`.*?`"), "")             // Remove inline code
                .replace(Regex("\[([^\]]+)\]\([^\)]+\)"), "$1") // Strip links, keep text
                .replace(Regex("[*#_~>]"), " ")          // Remove markdown symbols
                .replace(Regex("<[^>]*>"), " ")          // Remove HTML tags
                .replace(Regex("[\uD83C-\uDBFF\uDC00-\uDFFF]+"), "") // Remove emojis
                .replace(Regex("\s+"), " ")            // Normalize spaces
                .trim()
        }
    }
}
