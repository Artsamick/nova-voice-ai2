package com.nova.voiceai.core.audio

import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * Thread-safe ring buffer for raw 16-bit PCM samples.
 * Used for storing pre-roll audio before VAD speech trigger, ensuring initial syllables are not lost.
 */
class CircularAudioBuffer(val capacitySamples: Int) {
    private val buffer = ShortArray(capacitySamples)
    private var head = 0
    private var tail = 0
    private var size = 0
    private val lock = ReentrantLock()

    fun write(data: ShortArray, offset: Int = 0, length: Int = data.size) {
        lock.withLock {
            for (i in 0 until length) {
                buffer[head] = data[offset + i]
                head = (head + 1) % capacitySamples
                if (size < capacitySamples) {
                    size++
                } else {
                    tail = (tail + 1) % capacitySamples // overwrite oldest
                }
            }
        }
    }

    fun read(out: ShortArray, length: Int = out.size): Int {
        lock.withLock {
            val toRead = minOf(length, size)
            for (i in 0 until toRead) {
                out[i] = buffer[tail]
                tail = (tail + 1) % capacitySamples
            }
            size -= toRead
            return toRead
        }
    }

    fun readAll(): ShortArray {
        lock.withLock {
            val result = ShortArray(size)
            for (i in 0 until size) {
                result[i] = buffer[(tail + i) % capacitySamples]
            }
            return result
        }
    }

    fun available(): Int = lock.withLock { size }

    fun clear() {
        lock.withLock {
            head = 0
            tail = 0
            size = 0
        }
    }
}
