package com.nova.voiceai.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF090C10)
val DarkSurface = Color(0xFF13181F)
val DarkCard = Color(0xFF181F27)
val ModalBackground = Color(0xFF121A15)
val ModalSurface = Color(0xFF1B241F)

val AccentLime = Color(0xFFCBEA7B)
val AccentLimeDark = Color(0xFFA6C954)
val AccentCyan = Color(0xFF4EE2EC)
val AccentPurple = Color(0xFFB066FE)
val AccentPink = Color(0xFFFF4893)
val AccentAmber = Color(0xFFFFB039)

val TextPrimary = Color(0xFFF0F4F8)
val TextSecondary = Color(0xFF8B98A5)
val TextMuted = Color(0xFF536471)
val BorderDark = Color(0xFF233028)
