package com.nova.voiceai.core.llm

import android.util.Log
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

/**
 * OpenRouter.ai API Client with SSE (Server-Sent Events) streaming.
 * Default model: "openrouter/free"
 */
class OpenRouterClient(
    private var apiKey: String = "",
    var currentModel: String = "openrouter/free"
) : LlmEngine {
    private val tag = "OpenRouterClient"
    private val gson = Gson()
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private var activeCall: Call? = null

    fun setKey(key: String) {
        this.apiKey = key
    }

    suspend fun testConnection(): Boolean = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext false
        val request = Request.Builder()
            .url("https://openrouter.ai/api/v1/auth/key")
            .header("Authorization", "Bearer $apiKey")
            .get()
            .build()
        try {
            client.newCall(request).execute().use { response ->
                response.isSuccessful
            }
        } catch (e: Exception) {
            Log.e(tag, "Connection test failed: ${e.message}")
            false
        }
    }

    override fun streamResponse(
        messages: List<LlmMessage>,
        systemPrompt: String,
        temperature: Float,
        maxTokens: Int
    ): Flow<String> = callbackFlow {
        val root = JsonObject().apply {
            addProperty("model", currentModel)
            addProperty("stream", true)
            addProperty("temperature", temperature)
            addProperty("max_tokens", maxTokens)

            val messagesArr = JsonArray()
            val sysObj = JsonObject().apply {
                addProperty("role", "system")
                addProperty("content", systemPrompt)
            }
            messagesArr.add(sysObj)

            for (m in messages) {
                val mObj = JsonObject().apply {
                    addProperty("role", m.role)
                    addProperty("content", m.content)
                }
                messagesArr.add(mObj)
            }
            add("messages", messagesArr)
        }

        val requestBody = root.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url("https://openrouter.ai/api/v1/chat/completions")
            .header("Authorization", "Bearer $apiKey")
            .header("HTTP-Referer", "https://nova.voiceai")
            .header("X-Title", "NOVA Voice AI")
            .post(requestBody)
            .build()

        activeCall = client.newCall(request)
        activeCall?.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e(tag, "OpenRouter SSE call failed: ${e.message}")
                close(e)
            }

            override fun onResponse(call: Call, response: Response) {
                if (!response.isSuccessful) {
                    val err = "HTTP ${response.code}: ${response.message}"
                    Log.e(tag, "OpenRouter error: $err")
                    close(IOException(err))
                    return
                }

                val body = response.body
                if (body == null) {
                    close()
                    return
                }

                try {
                    val reader = BufferedReader(InputStreamReader(body.byteStream()))
                    var line: String? = null
                    while (reader.readLine().also { line = it } != null) {
                        val trimmed = line?.trim() ?: continue
                        if (trimmed.startsWith("data:")) {
                            val data = trimmed.removePrefix("data:").trim()
                            if (data == "[DONE]") {
                                break
                            }
                            try {
                                val json = gson.fromJson(data, JsonObject::class.java)
                                val choices = json.getAsJsonArray("choices")
                                if (choices != null && choices.size() > 0) {
                                    val delta = choices[0].asJsonObject.getAsJsonObject("delta")
                                    if (delta != null && delta.has("content")) {
                                        val content = delta.get("content").asString
                                        trySend(content)
                                    }
                                }
                            } catch (e: Exception) {
                                // Skip partial / metadata chunk
                            }
                        }
                    }
                    close()
                } catch (e: Exception) {
                    Log.w(tag, "Stream read interrupted: ${e.message}")
                    close(e)
                } finally {
                    body.close()
                }
            }
        })

        awaitClose {
            cancelInference()
        }
    }

    override fun cancelInference() {
        try {
            activeCall?.cancel()
            activeCall = null
            Log.i(tag, "OpenRouter call canceled.")
        } catch (e: Exception) {
            Log.w(tag, "Error canceling call: ${e.message}")
        }
    }
}
