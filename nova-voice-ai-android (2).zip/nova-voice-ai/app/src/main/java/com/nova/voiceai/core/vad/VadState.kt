package com.nova.voiceai.core.vad

enum class VadState {
    SILENCE,
    SPEECH_START,
    SPEAKING,
    SPEECH_ENDPOINT
}
