package com.nova.voiceai.engine

import android.content.Context
import android.util.Log
import com.nova.voiceai.core.audio.AudioRecorderManager
import com.nova.voiceai.core.audio.AudioTrackPlayer
import com.nova.voiceai.core.bargein.BargeInController
import com.nova.voiceai.core.llm.LlmEngine
import com.nova.voiceai.core.llm.LlmMessage
import com.nova.voiceai.core.speaker.SpeakerEnrollmentManager
import com.nova.voiceai.core.storage.ConversationRepository
import com.nova.voiceai.core.stt.SpeechToTextManager
import com.nova.voiceai.core.stt.SttResult
import com.nova.voiceai.core.tts.TextToSpeechManager
import com.nova.voiceai.core.tts.TtsState
import com.nova.voiceai.core.vad.VadDetector
import com.nova.voiceai.core.vad.VadState
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class ConversationCoordinator(
    private val context: Context,
    val stateMachine: ConversationStateMachine,
    val audioRecorder: AudioRecorderManager,
    val audioPlayer: AudioTrackPlayer,
    val vadDetector: VadDetector,
    val bargeInController: BargeInController,
    val speakerEnrollment: SpeakerEnrollmentManager,
    val sttManager: SpeechToTextManager,
    val ttsManager: TextToSpeechManager,
    val repository: ConversationRepository,
    var llmEngine: LlmEngine
) {
    private val tag = "ConversationCoordinator"
    private val coroutineScope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val currentGenerationId = AtomicLong(0L)
    private var llmJob: Job? = null
    private var endpointFallbackJob: Job? = null
    private val isProcessingQuery = AtomicBoolean(false)

    private val _liveCaptionFlow = MutableStateFlow("")
    val liveCaptionFlow: StateFlow<String> = _liveCaptionFlow.asStateFlow()

    private val _lastAiResponseFlow = MutableStateFlow("")
    val lastAiResponseFlow: StateFlow<String> = _lastAiResponseFlow.asStateFlow()

    init {
        observeStt()
        observeTts()
    }

    fun startSession() {
        stateMachine.transitionTo(ConversationState.INITIALIZING)
        sttManager.initRecognizer()

        val started = audioRecorder.startRecording(coroutineScope) { samples, length, rms ->
            onAudioFrame(samples, length, rms)
        }

        if (started) {
            stateMachine.transitionTo(ConversationState.LISTENING)
            sttManager.startListening("th-TH")
        } else {
            stateMachine.transitionTo(ConversationState.ERROR)
        }
    }

    fun stopSession() {
        endpointFallbackJob?.cancel()
        llmJob?.cancel()
        ttsManager.stopImmediately()
        sttManager.stopListening()
        audioRecorder.stopRecording()
        audioPlayer.stopAndFlush()
        stateMachine.transitionTo(ConversationState.IDLE)
        _liveCaptionFlow.value = ""
        isProcessingQuery.set(false)
    }

    private fun onAudioFrame(samples: ShortArray, length: Int, rms: Float) {
        val currentState = stateMachine.stateFlow.value

        // 1. SPECIFIC HUMAN VOICE BARGE-IN DETECTION DURING AI SPEAKING
        if (currentState == ConversationState.AI_SPEAKING) {
            val refPlayback = audioPlayer.getLastPlaybackRef()
            val shouldInterrupt = bargeInController.shouldBargeIn(
                micSamples = samples,
                micLength = length,
                micEnergy = rms,
                aiPlaybackRefSamples = refPlayback,
                isAiSpeaking = true
            )

            if (shouldInterrupt) {
                handleBargeIn()
                return
            }
        }

        // 2. VAD PROCESSING FOR SENTENCE ENDPOINT DETECTION
        val (vadState, _) = vadDetector.processFrame(samples, length)

        when (vadState) {
            VadState.SPEECH_START, VadState.SPEAKING -> {
                if (currentState == ConversationState.LISTENING) {
                    stateMachine.transitionTo(ConversationState.USER_SPEAKING)
                }
            }
            VadState.SPEECH_ENDPOINT -> {
                if (currentState == ConversationState.USER_SPEAKING) {
                    Log.i(tag, "VAD SPEECH_ENDPOINT detected! Finalizing speech for AI...")
                    stateMachine.transitionTo(ConversationState.ENDPOINT_DETECTED)
                    sttManager.stopListening()
                    stateMachine.transitionTo(ConversationState.TRANSCRIBING)

                    // Fallback timer: If STT onResults is delayed or omitted,
                    // send the accumulated text to AI within 400ms so user is never stuck!
                    endpointFallbackJob?.cancel()
                    endpointFallbackJob = coroutineScope.launch {
                        delay(400)
                        val textToSend = sttManager.latestPartialText.ifBlank { _liveCaptionFlow.value }
                        if (textToSend.isNotBlank() && !isProcessingQuery.get()) {
                            Log.i(tag, "Endpoint fallback timer triggered! Sending: '$textToSend'")
                            processUserQuery(textToSend)
                        } else if (!isProcessingQuery.get()) {
                            // Resume listening if nothing was heard
                            stateMachine.transitionTo(ConversationState.LISTENING)
                            sttManager.startListening("th-TH")
                        }
                    }
                }
            }
            VadState.SILENCE -> {
                // Listening continues smoothly
            }
        }
    }

    private fun handleBargeIn() {
        Log.i(tag, "Barge-in: Human user tone confirmed! Stopping AI voice instantly.")
        stateMachine.transitionTo(ConversationState.BARGE_IN_DETECTED)

        currentGenerationId.incrementAndGet()
        endpointFallbackJob?.cancel()
        llmJob?.cancel()
        llmEngine.cancelInference()
        ttsManager.stopImmediately()
        audioPlayer.stopAndFlush()

        isProcessingQuery.set(false)
        stateMachine.transitionTo(ConversationState.INTERRUPTED)
        stateMachine.transitionTo(ConversationState.LISTENING)
        sttManager.startListening("th-TH")
    }

    private fun observeStt() {
        coroutineScope.launch {
            sttManager.sttFlow.collect { result ->
                when (result) {
                    is SttResult.Partial -> {
                        _liveCaptionFlow.value = result.text
                        if (stateMachine.stateFlow.value == ConversationState.LISTENING) {
                            stateMachine.transitionTo(ConversationState.USER_SPEAKING)
                        }
                    }
                    is SttResult.Final -> {
                        endpointFallbackJob?.cancel()
                        _liveCaptionFlow.value = result.text
                        if (result.text.isNotBlank()) {
                            processUserQuery(result.text)
                        } else {
                            if (!isProcessingQuery.get()) {
                                stateMachine.transitionTo(ConversationState.LISTENING)
                                sttManager.startListening("th-TH")
                            }
                        }
                    }
                    is SttResult.Error -> {
                        Log.w(tag, "STT reported: ${result.message}")
                        if (!isProcessingQuery.get() && stateMachine.stateFlow.value != ConversationState.AI_SPEAKING) {
                            val text = _liveCaptionFlow.value
                            if (text.isNotBlank()) {
                                processUserQuery(text)
                            } else {
                                stateMachine.transitionTo(ConversationState.LISTENING)
                                sttManager.startListening("th-TH")
                            }
                        }
                    }
                }
            }
        }
    }

    private fun observeTts() {
        coroutineScope.launch {
            ttsManager.ttsStateFlow.collect { ttsState ->
                when (ttsState) {
                    TtsState.SPEAKING -> {
                        bargeInController.onAiStartedSpeaking()
                    }
                    TtsState.COMPLETED -> {
                        if (stateMachine.stateFlow.value == ConversationState.AI_SPEAKING) {
                            Log.i(tag, "AI finished speaking. Automatically resuming LISTENING for next turn.")
                            isProcessingQuery.set(false)
                            stateMachine.transitionTo(ConversationState.LISTENING)
                            sttManager.startListening("th-TH")
                        }
                    }
                    TtsState.INTERRUPTED -> {
                        isProcessingQuery.set(false)
                    }
                    else -> {}
                }
            }
        }
    }

    fun processUserQuery(query: String) {
        if (query.isBlank()) return
        if (isProcessingQuery.getAndSet(true)) return

        val genId = currentGenerationId.incrementAndGet()
        stateMachine.transitionTo(ConversationState.AI_THINKING)
        _liveCaptionFlow.value = query

        coroutineScope.launch {
            repository.addMessage("user", query)

            val systemPrompt = "คุณคือ NOVA ผู้ช่วยเสียง AI อัจฉริยะ ตอบคำถามด้วยภาษาไทยอย่างเป็นธรรมชาติ กระชับ ชัดเจน และเป็นมิตร ห้ามใส่โค้ดมาร์กดาวน์หรือสัญลักษณ์พิเศษเพราะข้อความจะถูกสังเคราะห์เป็นเสียงพูดโดยตรง"

            val history = listOf(LlmMessage("user", query))
            val responseAccumulator = StringBuilder()

            stateMachine.transitionTo(ConversationState.AI_SPEAKING)
            bargeInController.onAiStartedSpeaking()

            llmJob = launch {
                try {
                    llmEngine.streamResponse(history, systemPrompt).collect { token ->
                        if (genId != currentGenerationId.get()) {
                            // Cancelled by barge-in
                            return@collect
                        }
                        responseAccumulator.append(token)
                        _lastAiResponseFlow.value = responseAccumulator.toString()
                    }

                    val fullResponse = responseAccumulator.toString()
                    if (fullResponse.isNotBlank() && genId == currentGenerationId.get()) {
                        repository.addMessage("assistant", fullResponse)
                        ttsManager.speak(fullResponse, genId)
                    }
                } catch (e: Exception) {
                    Log.e(tag, "LLM Stream error: ${e.message}")
                    stateMachine.transitionTo(ConversationState.ERROR)
                    isProcessingQuery.set(false)
                }
            }
        }
    }
}
