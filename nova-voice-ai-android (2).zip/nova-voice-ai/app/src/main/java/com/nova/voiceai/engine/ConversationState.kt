package com.nova.voiceai.engine

enum class ConversationState(val displayThai: String) {
    IDLE("พร้อมเริ่มสนทนา"),
    INITIALIZING("กำลังเริ่มต้นระบบ..."),
    LISTENING("กำลังฟังคุณอยู่"),
    USER_SPEAKING("กำลังรับเสียงพูด"),
    ENDPOINT_DETECTED("ตรวจจับสิ้นสุดคำพูด"),
    TRANSCRIBING("กำลังแปลงเสียงเป็นข้อความ..."),
    AI_THINKING("กำลังคิดคำตอบ..."),
    AI_SPEAKING("กำลังตอบกลับ"),
    BARGE_IN_DETECTED("ตรวจพบการพูดแทรก!"),
    INTERRUPTED("ตัดเสียงเรียบร้อย"),
    RECONNECTING("กำลังเชื่อมต่อใหม่..."),
    ERROR("พบข้อผิดพลาด")
}
