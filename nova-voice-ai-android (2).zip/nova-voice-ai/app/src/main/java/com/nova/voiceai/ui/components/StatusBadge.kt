package com.nova.voiceai.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.voiceai.engine.ConversationState
import com.nova.voiceai.ui.theme.AccentLime
import com.nova.voiceai.ui.theme.AccentPink

@Composable
fun StatusBadge(state: ConversationState) {
    val (bgColor, textColor) = when (state) {
        ConversationState.ERROR -> Pair(AccentPink.copy(alpha = 0.2f), AccentPink)
        ConversationState.BARGE_IN_DETECTED -> Pair(Color(0xFFFFA000).copy(alpha = 0.2f), Color(0xFFFFA000))
        ConversationState.AI_SPEAKING, ConversationState.USER_SPEAKING -> Pair(AccentLime.copy(alpha = 0.2f), AccentLime)
        else -> Pair(Color(0xFF263238), Color(0xFF90A4AE))
    }

    Box(
        modifier = Modifier
            .background(bgColor, RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(
            text = state.displayThai,
            color = textColor,
            fontSize = 13.sp
        )
    }
}
