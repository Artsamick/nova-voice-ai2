package com.nova.voiceai.core.llm

data class LlmMessage(
    val role: String, // "system", "user", "assistant"
    val content: String
)
