package com.nova.voiceai.ui.screens.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.voiceai.core.storage.SecurePreferencesManager
import com.nova.voiceai.ui.theme.*

@Composable
fun AiSettingsTab(
    prefs: SecurePreferencesManager,
    onDone: () -> Unit
) {
    var selectedProvider by remember { mutableStateOf(prefs.selectedProvider) }
    var apiKeyText by remember { mutableStateOf(prefs.openRouterApiKey) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Text(
            text = "เลือก AI ที่อยากคุย",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
        Text(
            text = "สลับได้เสมอ บทสนทนายังต่อเนื่อง",
            fontSize = 13.sp,
            color = TextSecondary,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Provider Selector Cards
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Local AI Card
            val isLocal = selectedProvider == "LOCAL"
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (isLocal) Color(0xFF1E281F) else Color(0xFF151C17))
                    .border(
                        width = 1.dp,
                        color = if (isLocal) AccentLime else Color(0xFF263328),
                        shape = RoundedCornerShape(16.dp)
                    )
                    .clickable {
                        selectedProvider = "LOCAL"
                        prefs.selectedProvider = "LOCAL"
                    }
                    .padding(14.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Memory,
                            contentDescription = "AI ในเครื่อง",
                            tint = if (isLocal) AccentLime else TextSecondary,
                            modifier = Modifier.size(24.dp)
                        )
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(CircleShape)
                                .background(if (isLocal) AccentLime else Color.Transparent)
                                .border(1.5.dp, if (isLocal) AccentLime else TextSecondary, CircleShape)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "AI ในเครื่อง",
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "ใช้ฟรี · ไม่ต้องมีคีย์",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            // OpenRouter Card
            val isOpenRouter = selectedProvider == "OPENROUTER"
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (isOpenRouter) Color(0xFF1E281F) else Color(0xFF151C17))
                    .border(
                        width = 1.dp,
                        color = if (isOpenRouter) AccentLime else Color(0xFF263328),
                        shape = RoundedCornerShape(16.dp)
                    )
                    .clickable {
                        selectedProvider = "OPENROUTER"
                        prefs.selectedProvider = "OPENROUTER"
                    }
                    .padding(14.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Link,
                            contentDescription = "OpenRouter",
                            tint = if (isOpenRouter) AccentLime else TextSecondary,
                            modifier = Modifier.size(24.dp)
                        )
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(CircleShape)
                                .background(if (isOpenRouter) AccentLime else Color.Transparent)
                                .border(1.5.dp, if (isOpenRouter) AccentLime else TextSecondary, CircleShape)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "OpenRouter",
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "เลือกโมเดลที่คุณชอบ",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (selectedProvider == "LOCAL") {
            // Qwen3 Model Detail Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF161E18))
                    .border(1.dp, Color(0xFF233227), RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF263238)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Q", color = AccentCyan, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Qwen3 · 0.6B",
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0xFF2C382F))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("FREE", color = AccentLime, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Text(
                                text = "รุ่นเล็ก เริ่มตอบไว เหมาะกับการคุยทั่วไป",
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "บรรจุอยู่ในไฟล์ APK พร้อมใช้งานแบบ Offline ทันที ไม่ต้องใช้อินเทอร์เน็ต ตอบสนองรวดเร็วบนชิป ARM64",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("สถานะโมเดลในเครื่อง", color = TextSecondary, fontSize = 12.sp)
                        Text("พร้อมใช้งาน (100%)", color = AccentLime, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    LinearProgressIndicator(
                        progress = { 1.0f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp)),
                        color = AccentLime,
                        trackColor = Color(0xFF233327)
                    )

                    Text(
                        text = "โมเดลขนาดเล็กอาจตอบภาษาไทยได้ไม่แม่นเท่าโมเดลใหญ่ หากต้องการคุณภาพสูงขึ้น เลือก OpenRouter",
                        color = TextMuted,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        } else {
            // OpenRouter API Configuration Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF161E18))
                    .border(1.dp, Color(0xFF233227), RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Text("OpenRouter API Key", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = apiKeyText,
                        onValueChange = {
                            apiKeyText = it
                            prefs.openRouterApiKey = it
                        },
                        placeholder = { Text("sk-or-v1-...", color = TextMuted, fontSize = 13.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AccentLime,
                            unfocusedBorderColor = Color(0xFF2B3D2F),
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "โมเดลเริ่มต้น: openrouter/free (ฟรี ไม่เสียค่าใช้จ่าย) จัดเก็บคีย์ด้วย Android Keystore",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Bottom Finished Button
        Button(
            onClick = onDone,
            modifier = Modifier
                .align(Alignment.End)
                .height(44.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = AccentLime,
                contentColor = Color(0xFF0D140F)
            ),
            shape = RoundedCornerShape(22.dp)
        ) {
            Text("เสร็จแล้ว ✓", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}
