package com.nova.voiceai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.voiceai.engine.ConversationCoordinator
import com.nova.voiceai.engine.ConversationState
import com.nova.voiceai.ui.components.AudioWaveformVisualizer
import com.nova.voiceai.ui.components.HologramSphere3D
import com.nova.voiceai.ui.components.StatusBadge
import com.nova.voiceai.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainConversationScreen(
    coordinator: ConversationCoordinator,
    onOpenSettings: (Int) -> Unit
) {
    val state by coordinator.stateMachine.stateFlow.collectAsState()
    val micEnergy by coordinator.audioRecorder.micLevelFlow.collectAsState()
    val liveCaption by coordinator.liveCaptionFlow.collectAsState()
    val lastAiResponse by coordinator.lastAiResponseFlow.collectAsState()

    val isSessionActive = state != ConversationState.IDLE && state != ConversationState.ERROR

    Scaffold(
        containerColor = DarkBackground
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF0E131E), Color(0xFF07090E))
                    )
                ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top App Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { coordinator.stopSession() }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "AI Assistant",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                    Text(
                        text = "Always here to help you",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }

                IconButton(onClick = { onOpenSettings(0) }) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Settings", tint = TextPrimary)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // AI Response Bubble
            if (lastAiResponse.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color(0xFF261D38), Color(0xFF1A1A28))
                            )
                        )
                        .border(1.dp, Color(0xFF4A3469), RoundedCornerShape(18.dp))
                        .padding(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = AccentPurple,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = lastAiResponse,
                                color = TextPrimary,
                                fontSize = 14.sp,
                                lineHeight = 19.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "just now",
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.weight(0.6f))

            // 3D Holographic Sphere
            Box(
                modifier = Modifier
                    .size(280.dp),
                contentAlignment = Alignment.Center
            ) {
                HologramSphere3D(
                    state = state,
                    audioEnergy = micEnergy,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Sound Wave & Status
            AudioWaveformVisualizer(
                energy = micEnergy,
                isSpeaking = state == ConversationState.USER_SPEAKING || state == ConversationState.AI_SPEAKING
            )

            Spacer(modifier = Modifier.height(6.dp))
            StatusBadge(state = state)

            Spacer(modifier = Modifier.height(16.dp))

            // Prompt / Live Caption Pill
            val captionText = if (liveCaption.isNotBlank()) {
                liveCaption
            } else {
                "มีอะไรอยู่ในใจคุณ? พูดได้เลย ผมอยู่ตรงนี้"
            }

            Text(
                text = captionText,
                color = TextPrimary,
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 32.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // 3 Dots Indicator
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(AccentPurple))
                Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Color(0xFF37474F)))
                Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Color(0xFF37474F)))
            }

            Spacer(modifier = Modifier.weight(1f))

            // Bottom Voice Control Bar (Recreating Image 1)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 36.dp, vertical = 24.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Keyboard Button
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(
                        onClick = { /* Keyboard input dialog */ },
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E232E))
                    ) {
                        Icon(Icons.Default.Keyboard, contentDescription = "Keyboard", tint = TextSecondary)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Keyboard", color = TextSecondary, fontSize = 11.sp)
                }

                // Center Mic Tap-To-Speak Button
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(Color(0xFF9C27B0), Color(0xFF673AB7), Color(0xFF3F51B5))
                                )
                            )
                            .border(3.dp, Color(0xFFBA68C8), CircleShape)
                            .clickable {
                                if (isSessionActive) {
                                    coordinator.stopSession()
                                } else {
                                    coordinator.startSession()
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isSessionActive) Icons.Default.Stop else Icons.Default.Mic,
                            contentDescription = "Speak",
                            tint = Color.White,
                            modifier = Modifier.size(34.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isSessionActive) "Tap to pause" else "Tap to speak",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }

                // Cancel Button
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(
                        onClick = { coordinator.stopSession() },
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E232E))
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Cancel", tint = TextSecondary)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Cancel", color = TextSecondary, fontSize = 11.sp)
                }
            }
        }
    }
}
