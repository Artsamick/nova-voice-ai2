package com.nova.voiceai.core.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

class AudioTrackPlayer {
    private val tag = "AudioTrackPlayer"
    private var audioTrack: AudioTrack? = null
    private val isPlaying = AtomicBoolean(false)

    private val _playbackEnergyFlow = MutableStateFlow(0f)
    val playbackEnergyFlow: StateFlow<Float> = _playbackEnergyFlow.asStateFlow()

    // Reference playback buffer for Acoustic Echo Correlation
    private val refBufferLock = ReentrantLock()
    private val lastPlaybackChunk = ShortArray(AudioConstants.SAMPLES_PER_FRAME * 2)

    fun initTrack(sampleRate: Int = 24000) {
        val minBufferSize = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )

        audioTrack = AudioTrack(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build(),
            AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sampleRate)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build(),
            maxOf(minBufferSize, 8192),
            AudioTrack.MODE_STREAM,
            AudioManager.AUDIO_SESSION_ID_GENERATE
        )
        audioTrack?.play()
        isPlaying.set(true)
    }

    fun writeChunk(data: ShortArray, offset: Int = 0, size: Int = data.size): Int {
        if (!isPlaying.get() || audioTrack == null) return 0
        val written = audioTrack?.write(data, offset, size) ?: 0
        
        // Save copy of last played samples for Echo Correlator
        refBufferLock.withLock {
            val copyLen = minOf(size, lastPlaybackChunk.size)
            System.arraycopy(data, offset, lastPlaybackChunk, 0, copyLen)
        }

        var sum = 0.0
        for (i in offset until offset + size) {
            val v = data[i] / 32768.0
            sum += v * v
        }
        val rms = Math.sqrt(sum / size).toFloat()
        _playbackEnergyFlow.value = rms
        return written
    }

    fun getLastPlaybackRef(): ShortArray {
        refBufferLock.withLock {
            return lastPlaybackChunk.clone()
        }
    }

    fun stopAndFlush() {
        try {
            audioTrack?.pause()
            audioTrack?.flush()
            _playbackEnergyFlow.value = 0f
            refBufferLock.withLock {
                lastPlaybackChunk.fill(0)
            }
            Log.i(tag, "AudioTrack flushed instantly for barge-in")
        } catch (e: Exception) {
            Log.w(tag, "Exception during flush: ${e.message}")
        }
    }

    fun release() {
        isPlaying.set(false)
        try {
            audioTrack?.stop()
            audioTrack?.release()
            audioTrack = null
        } catch (e: Exception) {
            Log.w(tag, "Exception during release: ${e.message}")
        }
    }
}
