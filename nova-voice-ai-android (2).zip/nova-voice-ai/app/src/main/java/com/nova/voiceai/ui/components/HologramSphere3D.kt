package com.nova.voiceai.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.dp
import com.nova.voiceai.engine.ConversationState
import kotlin.math.*
import kotlin.random.Random

data class Particle(
    var angle: Float,
    var radius: Float,
    var speed: Float,
    var size: Float,
    var alpha: Float,
    var z: Float
)

@Composable
fun HologramSphere3D(
    modifier: Modifier = Modifier,
    state: ConversationState,
    audioEnergy: Float = 0f,
    preset: String = "BLUE_GOLD",
    sensitivity: Float = 1.2f,
    reduceMotion: Boolean = false
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb_rotation")
    
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (reduceMotion) 30000 else 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val breathingScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathing"
    )

    // Dynamic particles
    val particles = remember {
        List(80) {
            Particle(
                angle = Random.nextFloat() * 360f,
                radius = Random.nextFloat() * 110f + 60f,
                speed = (Random.nextFloat() * 1.5f + 0.5f) * if (Random.nextBoolean()) 1f else -1f,
                size = Random.nextFloat() * 3.5f + 1.5f,
                alpha = Random.nextFloat() * 0.6f + 0.3f,
                z = Random.nextFloat() * 2f - 1f
            )
        }
    }

    val baseScale = when (state) {
        ConversationState.USER_SPEAKING -> 1.0f + (audioEnergy * sensitivity * 0.8f).coerceAtMost(0.4f)
        ConversationState.AI_SPEAKING -> 1.0f + (audioEnergy * sensitivity * 0.9f).coerceAtMost(0.45f)
        ConversationState.AI_THINKING -> 0.9f + sin(rotationAngle * 0.1f) * 0.08f
        else -> breathingScale
    }

    val (primaryColor, secondaryColor, coreColor) = when (preset) {
        "ICE_BLUE" -> Triple(Color(0xFF38E1FF), Color(0xFF0072FF), Color(0xFFD6F8FF))
        "AMBER" -> Triple(Color(0xFFFFB300), Color(0xFFFF5722), Color(0xFFFFF3D0))
        "EMERALD" -> Triple(Color(0xFF00E676), Color(0xFF00B0FF), Color(0xFFD7FFE9))
        "PURPLE" -> Triple(Color(0xFFD500F9), Color(0xFF651FFF), Color(0xFFF8D7FF))
        else -> Triple(Color(0xFFB048FF), Color(0xFF00E5FF), Color(0xFFFFFFFF)) // BLUE_GOLD / NEURAL
    }

    Box(modifier = modifier) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val orbRadius = (min(size.width, size.height) * 0.32f) * baseScale

            // 1. Draw outer particle dust ring
            for (p in particles) {
                val currentAngle = (p.angle + (rotationAngle * p.speed)) % 360f
                val rad = Math.toRadians(currentAngle.toDouble())
                val px = center.x + cos(rad).toFloat() * (p.radius * baseScale)
                val py = center.y + sin(rad).toFloat() * (p.radius * baseScale * 0.55f) // 3D tilt

                val depthAlpha = ((p.z + 1f) / 2f * p.alpha).coerceIn(0.1f, 1f)
                drawCircle(
                    color = primaryColor.copy(alpha = depthAlpha),
                    radius = p.size * (1f + p.z * 0.3f),
                    center = Offset(px, py)
                )
            }

            // 2. Draw outer volumetric glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryColor.copy(alpha = 0.35f),
                        secondaryColor.copy(alpha = 0.15f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = orbRadius * 1.8f
                ),
                radius = orbRadius * 1.8f,
                center = center
            )

            // 3. Draw Holographic Plasma Core Sphere
            val sphereBrush = Brush.radialGradient(
                colors = listOf(
                    coreColor.copy(alpha = 0.95f),
                    primaryColor.copy(alpha = 0.85f),
                    secondaryColor.copy(alpha = 0.9f),
                    Color(0xFF0B0D19)
                ),
                center = Offset(center.x - orbRadius * 0.25f, center.y - orbRadius * 0.25f),
                radius = orbRadius
            )
            drawCircle(
                brush = sphereBrush,
                radius = orbRadius,
                center = center
            )

            // 4. Draw swirling internal plasma rings
            val ringCount = 3
            for (i in 1..ringCount) {
                val ringRot = rotationAngle * (if (i % 2 == 0) 1.2f else -0.9f) + (i * 45f)
                val rx = orbRadius * 0.88f
                val ry = orbRadius * 0.38f

                drawArc(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            primaryColor.copy(alpha = 0.8f),
                            secondaryColor.copy(alpha = 0.9f),
                            Color.Transparent,
                            primaryColor.copy(alpha = 0.8f)
                        )
                    ),
                    startAngle = ringRot,
                    sweepAngle = 260f,
                    useCenter = false,
                    topLeft = Offset(center.x - rx, center.y - ry),
                    size = androidx.compose.ui.geometry.Size(rx * 2, ry * 2),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4.dp.toPx())
                )
            }

            // 5. Rim light edge highlight
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.Transparent, primaryColor.copy(alpha = 0.4f), coreColor.copy(alpha = 0.8f)),
                    center = center,
                    radius = orbRadius
                ),
                radius = orbRadius,
                center = center,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.5.dp.toPx())
            )
        }
    }
}
