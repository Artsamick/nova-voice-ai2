package com.nova.voiceai.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlin.math.sin

@Composable
fun AudioWaveformVisualizer(
    modifier: Modifier = Modifier,
    energy: Float,
    isSpeaking: Boolean
) {
    Canvas(
        modifier = modifier
            .width(180.dp)
            .height(28.dp)
    ) {
        val barCount = 19
        val barSpacing = size.width / (barCount + 1)
        val centerY = size.height / 2f

        for (i in 0 until barCount) {
            val factor = if (isSpeaking) {
                (energy * 3.5f + (sin((i * 0.6f).toDouble()).toFloat() * 0.3f)).coerceIn(0.15f, 1.0f)
            } else {
                0.12f
            }
            val barHeight = (size.height * 0.85f * factor).coerceAtLeast(3f)

            drawLine(
                color = if (isSpeaking) Color(0xFFB066FE) else Color(0xFF455A64),
                start = Offset(barSpacing * (i + 1), centerY - barHeight / 2f),
                end = Offset(barSpacing * (i + 1), centerY + barHeight / 2f),
                strokeWidth = 3.dp.toPx(),
                cap = androidx.compose.ui.graphics.StrokeCap.Round
            )
        }
    }
}
