package com.nova.voiceai.ui.screens.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.voiceai.core.storage.SecurePreferencesManager
import com.nova.voiceai.ui.theme.*

@Composable
fun SphereSettingsTab(
    prefs: SecurePreferencesManager,
    onDone: () -> Unit
) {
    var selectedPreset by remember { mutableStateOf(prefs.orbPreset) }
    var audioSensitivity by remember { mutableStateOf(prefs.audioSensitivity) }
    var reduceMotion by remember { mutableStateOf(prefs.reduceMotion) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Text(
            text = "ให้เสียงมีรูปร่าง",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
        Text(
            text = when (selectedPreset) {
                "ICE_BLUE" -> "โฮโลแกรมสีไอซ์บลู"
                "AMBER" -> "โฮโลแกรมสีอำพัน"
                else -> "โฮโลแกรมสีน้ำเงิน–ทอง"
            },
            fontSize = 13.sp,
            color = TextSecondary,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Preset Cards Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Preset 1: Blue-Gold
            OrbPresetCard(
                name = "น้ำเงิน–ทอง",
                brush = Brush.horizontalGradient(listOf(Color(0xFF00E5FF), Color(0xFFFFD54F))),
                isSelected = selectedPreset == "BLUE_GOLD",
                onClick = {
                    selectedPreset = "BLUE_GOLD"
                    prefs.orbPreset = "BLUE_GOLD"
                },
                modifier = Modifier.weight(1f)
            )

            // Preset 2: Ice Blue
            OrbPresetCard(
                name = "ไอซ์บลู",
                brush = Brush.radialGradient(listOf(Color(0xFF80D8FF), Color(0xFF0091EA))),
                isSelected = selectedPreset == "ICE_BLUE",
                onClick = {
                    selectedPreset = "ICE_BLUE"
                    prefs.orbPreset = "ICE_BLUE"
                },
                modifier = Modifier.weight(1f)
            )

            // Preset 3: Amber
            OrbPresetCard(
                name = "อำพัน",
                brush = Brush.radialGradient(listOf(Color(0xFFFFD54F), Color(0xFFFF6D00))),
                isSelected = selectedPreset == "AMBER",
                onClick = {
                    selectedPreset = "AMBER"
                    prefs.orbPreset = "AMBER"
                },
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Audio Sensitivity Slider
        Text("ความไวต่อเสียง ${(audioSensitivity * 10).toInt() / 10.0}x", color = TextPrimary, fontSize = 13.sp)
        Slider(
            value = audioSensitivity,
            onValueChange = {
                audioSensitivity = it
                prefs.audioSensitivity = it
            },
            valueRange = 0.5f..2.5f,
            colors = SliderDefaults.colors(
                thumbColor = AccentLime,
                activeTrackColor = AccentLime,
                inactiveTrackColor = Color(0xFF2C3B30)
            )
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Reduce Motion Checkbox
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.clickable {
                reduceMotion = !reduceMotion
                prefs.reduceMotion = reduceMotion
            }
        ) {
            Checkbox(
                checked = reduceMotion,
                onCheckedChange = {
                    reduceMotion = it
                    prefs.reduceMotion = it
                },
                colors = CheckboxDefaults.colors(
                    checkedColor = AccentLime,
                    checkmarkColor = Color(0xFF0A0F0C),
                    uncheckedColor = Color(0xFF455A64)
                )
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("ลดการเคลื่อนไหว", color = TextPrimary, fontSize = 14.sp)
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Bottom Finished Button
        Button(
            onClick = onDone,
            modifier = Modifier
                .align(Alignment.End)
                .height(44.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = AccentLime,
                contentColor = Color(0xFF0D140F)
            ),
            shape = RoundedCornerShape(22.dp)
        ) {
            Text("เสร็จแล้ว ✓", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}

@Composable
fun OrbPresetCard(
    name: String,
    brush: Brush,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (isSelected) Color(0xFF1E281F) else Color(0xFF151C17))
            .border(
                width = 1.dp,
                color = if (isSelected) AccentLime else Color(0xFF263328),
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onClick)
            .padding(vertical = 16.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(brush)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = name,
                color = if (isSelected) TextPrimary else TextSecondary,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
            )
        }
    }
}
