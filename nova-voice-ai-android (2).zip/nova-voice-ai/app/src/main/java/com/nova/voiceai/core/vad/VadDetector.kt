package com.nova.voiceai.core.vad

import android.util.Log

class VadDetector {
    private val tag = "VadDetector"
    private var currentState = VadState.SILENCE
    private var silenceDurationMs = 0L
    private var speechDurationMs = 0L

    // 650ms of silence after speaking reliably detects sentence endpoint
    var endpointSilenceThresholdMs = 650L
    var voiceSensitivity: Float = 1.0f
        set(value) {
            field = value
            nativeSetSensitivity(value)
        }

    companion object {
        init {
            try {
                System.loadLibrary("nova_native")
            } catch (e: UnsatisfiedLinkError) {
                Log.e("VadDetector", "Failed to load nova_native library: ${e.message}")
            }
        }
    }

    private external fun nativeSetSensitivity(sensitivity: Float)
    private external fun nativeProcessFrame(
        audioData: ShortArray,
        length: Int,
        outEnergy: FloatArray
    ): Boolean

    fun processFrame(samples: ShortArray, length: Int, frameDurationMs: Long = 30L): Pair<VadState, Float> {
        val energyHolder = FloatArray(1)
        val isRawVoice = nativeProcessFrame(samples, length, energyHolder)
        val currentEnergy = energyHolder[0]

        when (currentState) {
            VadState.SILENCE -> {
                if (isRawVoice) {
                    speechDurationMs = frameDurationMs
                    currentState = VadState.SPEECH_START
                }
            }
            VadState.SPEECH_START -> {
                if (isRawVoice) {
                    speechDurationMs += frameDurationMs
                    // Require at least 90ms of continuous voice before entering SPEAKING
                    if (speechDurationMs >= 90L) {
                        currentState = VadState.SPEAKING
                        silenceDurationMs = 0L
                    }
                } else {
                    currentState = VadState.SILENCE
                    speechDurationMs = 0L
                }
            }
            VadState.SPEAKING -> {
                if (isRawVoice) {
                    speechDurationMs += frameDurationMs
                    silenceDurationMs = 0L // reset silence accumulator
                } else {
                    silenceDurationMs += frameDurationMs
                    // When silence reaches threshold after user was speaking -> Endpoint reached!
                    if (silenceDurationMs >= endpointSilenceThresholdMs) {
                        currentState = VadState.SPEECH_ENDPOINT
                    }
                }
            }
            VadState.SPEECH_ENDPOINT -> {
                // Instant one-shot trigger, resets immediately
                currentState = VadState.SILENCE
                speechDurationMs = 0L
                silenceDurationMs = 0L
            }
        }

        return Pair(currentState, currentEnergy)
    }

    fun reset() {
        currentState = VadState.SILENCE
        speechDurationMs = 0L
        silenceDurationMs = 0L
    }
}
