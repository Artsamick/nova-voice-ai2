package com.nova.voiceai.core.llm

import kotlinx.coroutines.flow.Flow

interface LlmEngine {
    fun streamResponse(
        messages: List<LlmMessage>,
        systemPrompt: String,
        temperature: Float = 0.7f,
        maxTokens: Int = 512
    ): Flow<String>

    fun cancelInference()
}
