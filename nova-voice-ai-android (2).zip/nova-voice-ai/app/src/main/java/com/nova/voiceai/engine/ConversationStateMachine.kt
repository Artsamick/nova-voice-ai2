package com.nova.voiceai.engine

import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ConversationStateMachine {
    private val tag = "ConversationStateMachine"

    private val _stateFlow = MutableStateFlow(ConversationState.IDLE)
    val stateFlow: StateFlow<ConversationState> = _stateFlow.asStateFlow()

    fun transitionTo(newState: ConversationState) {
        val current = _stateFlow.value
        if (current == newState) return

        // State Machine validation
        val valid = when (newState) {
            ConversationState.IDLE -> true
            ConversationState.INITIALIZING -> current == ConversationState.IDLE || current == ConversationState.ERROR
            ConversationState.LISTENING -> true
            ConversationState.USER_SPEAKING -> current == ConversationState.LISTENING || current == ConversationState.AI_SPEAKING
            ConversationState.ENDPOINT_DETECTED -> current == ConversationState.USER_SPEAKING
            ConversationState.TRANSCRIBING -> current == ConversationState.ENDPOINT_DETECTED
            ConversationState.AI_THINKING -> current == ConversationState.TRANSCRIBING || current == ConversationState.USER_SPEAKING
            ConversationState.AI_SPEAKING -> current == ConversationState.AI_THINKING
            ConversationState.BARGE_IN_DETECTED -> current == ConversationState.AI_SPEAKING
            ConversationState.INTERRUPTED -> current == ConversationState.BARGE_IN_DETECTED
            ConversationState.RECONNECTING -> true
            ConversationState.ERROR -> true
        }

        if (valid) {
            Log.i(tag, "State Transition: $current -> $newState")
            _stateFlow.value = newState
        } else {
            Log.w(tag, "Invalid State Transition attempted: $current -> $newState (forcing)")
            _stateFlow.value = newState
        }
    }
}
