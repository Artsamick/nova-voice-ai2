package com.nova.voiceai.ui.screens.tabs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.voiceai.core.storage.SecurePreferencesManager
import com.nova.voiceai.ui.theme.*

@Composable
fun VoiceSettingsTab(
    prefs: SecurePreferencesManager,
    onTestVoice: () -> Unit,
    onDone: () -> Unit
) {
    var speechRate by remember { mutableStateOf(prefs.speechRate) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Text(
            text = "คุยในแบบที่เป็นคุณ",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Dropdown 1: Language
        Text("ภาษาที่พูด", color = TextSecondary, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF151C17))
                .border(1.dp, Color(0xFF263328), RoundedCornerShape(12.dp))
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("ไทย", color = TextPrimary, fontSize = 14.sp)
                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = TextSecondary)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Dropdown 2: TTS Engine
        Text("ระบบเสียงพูดของ NOVA", color = TextSecondary, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF151C17))
                .border(1.dp, Color(0xFF263328), RoundedCornerShape(12.dp))
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("เสียงระบบ / เสียงออนไลน์มาตรฐาน", color = TextPrimary, fontSize = 14.sp)
                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = TextSecondary)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Dropdown 3: Fallback Voice
        Text("เสียงในเครื่อง (สำรอง)", color = TextSecondary, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF151C17))
                .border(1.dp, Color(0xFF263328), RoundedCornerShape(12.dp))
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("เสียงระบบตามภาษา", color = TextPrimary, fontSize = 14.sp)
                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = TextSecondary)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Speech Rate Slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("ความเร็วเสียง ${(speechRate * 100).toInt() / 100.0}x", color = TextPrimary, fontSize = 13.sp)
        }
        Slider(
            value = speechRate,
            onValueChange = {
                speechRate = it
                prefs.speechRate = it
            },
            valueRange = 0.75f..1.5f,
            colors = SliderDefaults.colors(
                thumbColor = AccentLime,
                activeTrackColor = AccentLime,
                inactiveTrackColor = Color(0xFF2C3B30)
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Try Voice Button
        OutlinedButton(
            onClick = onTestVoice,
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
            border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0xFF2E3E32)))
        ) {
            Text("ลองฟังเสียง", fontSize = 13.sp)
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Bottom Finished Button
        Button(
            onClick = onDone,
            modifier = Modifier
                .align(Alignment.End)
                .height(44.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = AccentLime,
                contentColor = Color(0xFF0D140F)
            ),
            shape = RoundedCornerShape(22.dp)
        ) {
            Text("เสร็จแล้ว ✓", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}
