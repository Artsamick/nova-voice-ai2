package com.nova.voiceai.core.bargein

import android.util.Log

enum class BargeInSensitivity {
    OFF,
    NORMAL,
    FAST,
    VERY_FAST,
    OWNER_ONLY
}

/**
 * Intelligent Barge-in Controller.
 * Guarantees that only HUMAN VOICE TONE (85 Hz - 280 Hz) can interrupt the conversation.
 * If the sound is the AI's own voice coming from the speaker, Barge-in is strictly blocked.
 */
class BargeInController {
    private val tag = "BargeInController"
    var mode: BargeInSensitivity = BargeInSensitivity.NORMAL
    var enabled: Boolean = true

    // Cooldown window: Protect first 400ms after AI starts speaking to avoid speaker turn-on click
    private var aiSpeechStartTime = 0L
    private val blankingPeriodMs = 400L

    // Minimum consecutive human voice frames to trigger barge-in (60ms)
    private var consecutiveHumanFrames = 0
    private val requiredConsecutiveFrames = 2

    companion object {
        init {
            try {
                System.loadLibrary("nova_native")
            } catch (e: UnsatisfiedLinkError) {
                Log.e("BargeInController", "Failed to load nova_native library: ${e.message}")
            }
        }
    }

    private external fun nativeAnalyzeHumanVoicePitch(
        audioData: ShortArray,
        length: Int,
        sampleRate: Int,
        outResult: FloatArray
    ): Boolean

    private external fun nativeCheckAiEchoCorrelation(
        micBuffer: ShortArray,
        refPlaybackBuffer: ShortArray,
        length: Int
    ): Float

    fun onAiStartedSpeaking() {
        aiSpeechStartTime = System.currentTimeMillis()
        consecutiveHumanFrames = 0
    }

    /**
     * Determines whether the incoming microphone audio represents a real human speaking,
     * rather than the AI's own output from the phone's speaker.
     */
    fun shouldBargeIn(
        micSamples: ShortArray,
        micLength: Int,
        micEnergy: Float,
        aiPlaybackRefSamples: ShortArray?,
        isAiSpeaking: Boolean
    ): Boolean {
        if (!enabled || mode == BargeInSensitivity.OFF || !isAiSpeaking) {
            consecutiveHumanFrames = 0
            return false
        }

        val elapsedSinceAiStart = System.currentTimeMillis() - aiSpeechStartTime
        if (elapsedSinceAiStart < blankingPeriodMs) {
            // Inside blanking period -> Block all barge-in to let AI sentence begin cleanly
            return false
        }

        // 1. Check Normalized Cross-Correlation with AI Playback Reference
        if (aiPlaybackRefSamples != null && aiPlaybackRefSamples.size >= micLength) {
            val echoCorr = nativeCheckAiEchoCorrelation(micSamples, aiPlaybackRefSamples, micLength)
            if (echoCorr > 0.36f) {
                // Sound correlates strongly with what AI is playing -> IT IS AI VOICE! Do not stop!
                consecutiveHumanFrames = 0
                return false
            }
        }

        // 2. Minimum energy threshold check
        val minEnergy = when (mode) {
            BargeInSensitivity.VERY_FAST -> 0.035f
            BargeInSensitivity.FAST -> 0.050f
            BargeInSensitivity.NORMAL -> 0.065f
            BargeInSensitivity.OWNER_ONLY -> 0.070f
            BargeInSensitivity.OFF -> Float.MAX_VALUE
        }

        if (micEnergy < minEnergy) {
            consecutiveHumanFrames = 0
            return false
        }

        // 3. HUMAN VOICE PITCH & TONE VALIDATION (F0 in 85 Hz - 280 Hz)
        val pitchResult = FloatArray(3) // [pitchHz, maxCorr, zcr]
        val isHumanTone = nativeAnalyzeHumanVoicePitch(micSamples, micLength, 16000, pitchResult)
        val detectedPitch = pitchResult[0]
        val voicingConfidence = pitchResult[1]

        if (!isHumanTone || detectedPitch < 85.0f || detectedPitch > 280.0f || voicingConfidence < 0.50f) {
            // Non-human sound, mechanical noise, speaker distortion, or hiss
            consecutiveHumanFrames = 0
            return false
        }

        consecutiveHumanFrames++

        if (consecutiveHumanFrames >= requiredConsecutiveFrames) {
            Log.i(tag, "HUMAN VOICE BARGE-IN VERIFIED! Pitch=${detectedPitch}Hz, Voicing=${voicingConfidence}, Energy=${micEnergy}")
            consecutiveHumanFrames = 0
            return true
        }

        return false
    }
}
