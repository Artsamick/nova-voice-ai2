package com.nova.voiceai.core.llm

import android.content.Context
import android.util.Log
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import java.io.File

/**
 * Offline Llama C++ JNI bridge for Qwen3-0.6B GGUF.
 * Directly runs inference on ARM64 CPU without requiring network connectivity.
 */
class LocalLlamaEngine(private val context: Context) : LlmEngine {
    private val tag = "LocalLlamaEngine"
    private var isLoaded = false

    companion object {
        init {
            try {
                System.loadLibrary("nova_native")
            } catch (e: UnsatisfiedLinkError) {
                Log.e("LocalLlamaEngine", "Failed to load nova_native library: ${e.message}")
            }
        }
    }

    private external fun nativeLoadModel(modelPath: String, nThreads: Int, contextSize: Int): Boolean
    private external fun nativeCancelInference()
    private external fun nativeGenerateStreaming(prompt: String, callback: NativeTokenCallback)

    interface NativeTokenCallback {
        fun onToken(token: String)
        fun onComplete()
    }

    fun loadModel(modelFile: File, threads: Int = 4, ctxSize: Int = 2048): Boolean {
        if (!modelFile.exists()) {
            Log.w(tag, "Model file does not exist at: ${modelFile.absolutePath}")
            return false
        }
        isLoaded = nativeLoadModel(modelFile.absolutePath, threads, ctxSize)
        Log.i(tag, "Local Qwen3-0.6B GGUF loaded: $isLoaded")
        return isLoaded
    }

    override fun streamResponse(
        messages: List<LlmMessage>,
        systemPrompt: String,
        temperature: Float,
        maxTokens: Int
    ): Flow<String> = callbackFlow {
        val fullPrompt = buildChatPrompt(messages, systemPrompt)

        val callback = object : NativeTokenCallback {
            override fun onToken(token: String) {
                trySend(token)
            }

            override fun onComplete() {
                close()
            }
        }

        try {
            nativeGenerateStreaming(fullPrompt, callback)
        } catch (e: Exception) {
            Log.e(tag, "Inference error: ${e.message}", e)
            close(e)
        }

        awaitClose {
            nativeCancelInference()
        }
    }

    override fun cancelInference() {
        nativeCancelInference()
    }

    private fun buildChatPrompt(messages: List<LlmMessage>, systemPrompt: String): String {
        val sb = StringBuilder()
        sb.append("<|im_start|>system\n$systemPrompt<|im_end|>\n")
        for (m in messages) {
            sb.append("<|im_start|>${m.role}\n${m.content}<|im_end|>\n")
        }
        sb.append("<|im_start|>assistant\n")
        return sb.toString()
    }
}
