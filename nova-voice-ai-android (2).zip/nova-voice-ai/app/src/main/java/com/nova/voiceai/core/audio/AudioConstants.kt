package com.nova.voiceai.core.audio

object AudioConstants {
    const val SAMPLE_RATE = 16000 // 16kHz for Whisper & VAD
    const val CHANNEL_CONFIG = android.media.AudioFormat.CHANNEL_IN_MONO
    const val AUDIO_FORMAT = android.media.AudioFormat.ENCODING_PCM_16BIT
    const val FRAME_SIZE_MS = 30 // 30ms frames
    const val SAMPLES_PER_FRAME = (SAMPLE_RATE * FRAME_SIZE_MS) / 1000 // 480 samples
    const val BYTES_PER_SAMPLE = 2 // 16-bit
    const val FRAME_SIZE_BYTES = SAMPLES_PER_FRAME * BYTES_PER_SAMPLE // 960 bytes

    const val DEFAULT_SILENCE_TIMEOUT_MS = 700L
    const val MIN_SPEECH_DURATION_MS = 250L
    const val MAX_SPEECH_DURATION_MS = 15000L
}
