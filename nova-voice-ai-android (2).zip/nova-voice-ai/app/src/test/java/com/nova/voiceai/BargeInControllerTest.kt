package com.nova.voiceai

import com.nova.voiceai.core.bargein.BargeInController
import com.nova.voiceai.core.bargein.BargeInSensitivity
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class BargeInControllerTest {

    private lateinit var controller: BargeInController

    @Before
    fun setup() {
        controller = BargeInController()
    }

    @Test
    fun testBargeInDisabledWhenOff() {
        controller.mode = BargeInSensitivity.OFF
        val samples = ShortArray(480)
        val result = controller.shouldBargeIn(
            micSamples = samples,
            micLength = 480,
            micEnergy = 0.5f,
            aiPlaybackRefSamples = null,
            isAiSpeaking = true
        )
        assertFalse(result)
    }

    @Test
    fun testBargeInDisabledWhenAiNotSpeaking() {
        controller.mode = BargeInSensitivity.NORMAL
        val samples = ShortArray(480)
        val result = controller.shouldBargeIn(
            micSamples = samples,
            micLength = 480,
            micEnergy = 0.5f,
            aiPlaybackRefSamples = null,
            isAiSpeaking = false
        )
        assertFalse(result)
    }

    @Test
    fun testBargeInBlockedDuringBlankingWindow() {
        controller.mode = BargeInSensitivity.NORMAL
        controller.onAiStartedSpeaking() // Reset blanking timer
        val samples = ShortArray(480) { 1000 }

        // Under 400ms blanking window, it must strictly return false
        val result = controller.shouldBargeIn(
            micSamples = samples,
            micLength = 480,
            micEnergy = 0.2f,
            aiPlaybackRefSamples = null,
            isAiSpeaking = true
        )
        assertFalse("Barge-in should be suppressed during the initial blanking window", result)
    }

    @Test
    fun testBargeInRejectsLowEnergyNoise() {
        controller.mode = BargeInSensitivity.NORMAL
        val samples = ShortArray(480)
        val result = controller.shouldBargeIn(
            micSamples = samples,
            micLength = 480,
            micEnergy = 0.01f, // below 0.065f threshold
            aiPlaybackRefSamples = null,
            isAiSpeaking = true
        )
        assertFalse(result)
    }
}
