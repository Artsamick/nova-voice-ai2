package com.nova.voiceai

import com.nova.voiceai.core.audio.CircularAudioBuffer
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

class CircularAudioBufferTest {

    @Test
    fun testWriteAndReadAll() {
        val buffer = CircularAudioBuffer(10)
        val input = shortArrayOf(1, 2, 3, 4, 5)
        buffer.write(input)

        assertEquals(5, buffer.available())
        assertArrayEquals(input, buffer.readAll())
    }

    @Test
    fun testOverwriteOldestWhenExceedingCapacity() {
        val buffer = CircularAudioBuffer(4)
        buffer.write(shortArrayOf(10, 20, 30))
        buffer.write(shortArrayOf(40, 50)) // capacity 4, oldest 10 dropped

        assertEquals(4, buffer.available())
        val out = ShortArray(4)
        val readCount = buffer.read(out)
        assertEquals(4, readCount)
        assertArrayEquals(shortArrayOf(20, 30, 40, 50), out)
    }
}
