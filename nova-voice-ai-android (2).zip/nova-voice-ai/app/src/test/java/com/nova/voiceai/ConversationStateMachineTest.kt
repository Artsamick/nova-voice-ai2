package com.nova.voiceai

import com.nova.voiceai.engine.ConversationState
import com.nova.voiceai.engine.ConversationStateMachine
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

class ConversationStateMachineTest {

    private lateinit var stateMachine: ConversationStateMachine

    @Before
    fun setup() {
        stateMachine = ConversationStateMachine()
    }

    @Test
    fun testInitialStateIsIdle() {
        assertEquals(ConversationState.IDLE, stateMachine.stateFlow.value)
    }

    @Test
    fun testValidTransitionFromIdleToListening() {
        stateMachine.transitionTo(ConversationState.INITIALIZING)
        assertEquals(ConversationState.INITIALIZING, stateMachine.stateFlow.value)

        stateMachine.transitionTo(ConversationState.LISTENING)
        assertEquals(ConversationState.LISTENING, stateMachine.stateFlow.value)
    }

    @Test
    fun testSpeechTurnFlow() {
        stateMachine.transitionTo(ConversationState.LISTENING)
        stateMachine.transitionTo(ConversationState.USER_SPEAKING)
        assertEquals(ConversationState.USER_SPEAKING, stateMachine.stateFlow.value)

        stateMachine.transitionTo(ConversationState.ENDPOINT_DETECTED)
        assertEquals(ConversationState.ENDPOINT_DETECTED, stateMachine.stateFlow.value)

        stateMachine.transitionTo(ConversationState.TRANSCRIBING)
        assertEquals(ConversationState.TRANSCRIBING, stateMachine.stateFlow.value)

        stateMachine.transitionTo(ConversationState.AI_THINKING)
        assertEquals(ConversationState.AI_THINKING, stateMachine.stateFlow.value)

        stateMachine.transitionTo(ConversationState.AI_SPEAKING)
        assertEquals(ConversationState.AI_SPEAKING, stateMachine.stateFlow.value)
    }

    @Test
    fun testBargeInTransition() {
        stateMachine.transitionTo(ConversationState.LISTENING)
        stateMachine.transitionTo(ConversationState.AI_THINKING)
        stateMachine.transitionTo(ConversationState.AI_SPEAKING)

        // Trigger Barge-In
        stateMachine.transitionTo(ConversationState.BARGE_IN_DETECTED)
        assertEquals(ConversationState.BARGE_IN_DETECTED, stateMachine.stateFlow.value)

        stateMachine.transitionTo(ConversationState.INTERRUPTED)
        assertEquals(ConversationState.INTERRUPTED, stateMachine.stateFlow.value)

        stateMachine.transitionTo(ConversationState.LISTENING)
        assertEquals(ConversationState.LISTENING, stateMachine.stateFlow.value)
    }
}
