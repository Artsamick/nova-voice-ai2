package com.nova.voiceai

import com.nova.voiceai.core.tts.TextToSpeechManager
import org.junit.Assert.assertEquals
import org.junit.Test

class TextSanitizerTest {

    @Test
    fun testMarkdownRemoval() {
        val input = "สวัสดีครับ **ข้อความสำคัญ** และ _เน้นคำ_ รวมทั้ง `val x = 10`"
        val clean = TextToSpeechManager.sanitizeTextForSpeech(input)
        assertEquals("สวัสดีครับ ข้อความสำคัญ และ เน้นคำ รวมทั้ง", clean)
    }

    @Test
    fun testCodeBlockRemoval() {
        val input = "นี่คือคำตอบ:\n```python\nprint('hello')\n```\nจบการทำงานครับ"
        val clean = TextToSpeechManager.sanitizeTextForSpeech(input)
        assertEquals("นี่คือคำตอบ: จบการทำงานครับ", clean)
    }

    @Test
    fun testLinkStripping() {
        val input = "ดูข้อมูลเพิ่มเติมได้ที่ [เว็บไซต์ทางการ](https://example.com) ครับ"
        val clean = TextToSpeechManager.sanitizeTextForSpeech(input)
        assertEquals("ดูข้อมูลเพิ่มเติมได้ที่ เว็บไซต์ทางการ ครับ", clean)
    }
}
