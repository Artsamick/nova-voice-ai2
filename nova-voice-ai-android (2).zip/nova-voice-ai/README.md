# NOVA — Voice AI (Android Native)

NOVA is a high-performance, real-time native Android voice assistant application engineered with Kotlin, Jetpack Compose, C++/JNI DSP, and a Full-Duplex conversational pipeline.

## Key Capabilities
1. **Full-Duplex Voice Engine**: Seamless concurrent microphone capture and audio playback.
2. **Instant Barge-in & Echo Cancellation**: Hardware & software AEC spectral subtraction to immediately interrupt AI TTS when the user speaks.
3. **Voice Activity Detection (VAD)**: Adaptive threshold, noise floor tracking, and 700ms silence endpointing.
4. **Progressive Speaker Recognition**: Passive acoustic voice enrollment without forcing repetitive sentence reading.
5. **Dual AI Inference Modes**:
   - **Offline Local AI**: Bundled Qwen3-0.6B GGUF model via llama.cpp JNI on ARM64.
   - **Online OpenRouter**: Streaming SSE client with free models routing (`openrouter/free`).
6. **Thai STT & TTS**: Natural Thai text-to-speech with markdown and emoji stripping, paired with Android speech recognition.
7. **3D Holographic Particle Orb**: OpenGL ES & Compose Canvas shader orb with organic noise motion, audio-reactive pulses, and custom color presets.

## Project Structure
- `app/src/main/cpp/`: C++ DSP, VAD, and llama bridge native libraries.
- `app/src/main/java/com/nova/voiceai/core/audio/`: AudioRecord, AudioTrack, AEC, CircularBuffer.
- `app/src/main/java/com/nova/voiceai/core/vad/`: Voice Activity Detection engine.
- `app/src/main/java/com/nova/voiceai/core/bargein/`: Double-talk & Barge-in detector.
- `app/src/main/java/com/nova/voiceai/core/speaker/`: Progressive Speaker Profile & Cosine Similarity.
- `app/src/main/java/com/nova/voiceai/core/stt/`: Thai Speech-to-Text manager.
- `app/src/main/java/com/nova/voiceai/core/tts/`: Natural Thai Text-to-Speech manager.
- `app/src/main/java/com/nova/voiceai/core/llm/`: Local GGUF and OpenRouter streaming engines.
- `app/src/main/java/com/nova/voiceai/engine/`: State Machine and Master Coordinator.
- `app/src/main/java/com/nova/voiceai/ui/`: Jetpack Compose UI matching the 4 reference designs.

## Building the APK
To build `NOVA-Voice-AI.apk`:
```bash
./gradlew assembleDebug
```
The APK will be generated at `app/build/outputs/apk/debug/app-debug.apk`.
