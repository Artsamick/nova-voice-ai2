#!/bin/bash
set -e
echo "Setting up NOVA Voice AI Android Native Project..."
chmod +x gradlew
python3 scripts/download_models.py
echo "Ready for Gradle build!"
