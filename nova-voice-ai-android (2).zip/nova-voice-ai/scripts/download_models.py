#!/usr/bin/env python3
import os
import sys
import urllib.request
import hashlib

ASSETS_DIR = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "assets", "models")
os.makedirs(ASSETS_DIR, exist_ok=True)

# Qwen3-0.6B GGUF Model Info
# Source: https://huggingface.co/Qwen/Qwen3-0.6B-GGUF
QWEN_MODEL_URL = "https://huggingface.co/Qwen/Qwen3-0.6B-GGUF/resolve/main/qwen3-0_6b-instruct-q4_k_m.gguf"
QWEN_DEST_PATH = os.path.join(ASSETS_DIR, "qwen3-0_6b-instruct-q4_k_m.gguf")

def download_file(url, dest_path):
    print(f"Downloading model from {url} to {dest_path}...")
    try:
        urllib.request.urlretrieve(url, dest_path)
        print(f"Successfully downloaded {dest_path} ({os.path.getsize(dest_path)} bytes)")
    except Exception as e:
        print(f"Download failed: {e}")
        # Create metadata manifest if offline build
        meta_file = dest_path + ".meta"
        with open(meta_file, "w") as f:
            f.write(f"model_source={url}\nstatus=pending_bundle\n")

if __name__ == "__main__":
    download_file(QWEN_MODEL_URL, QWEN_DEST_PATH)
